--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.9 (Debian 13.9-1.pgdg110+1)
-- Dumped by pg_dump version 15.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE hue;
--
-- Name: hue; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE hue WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE hue OWNER TO admin;

\connect hue

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: admin
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO admin;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: admin
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO admin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_group_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO admin;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO admin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO admin;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO admin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO admin;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO admin;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO admin;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO admin;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO admin;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO admin;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO admin;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.authtoken_token OWNER TO admin;

--
-- Name: axes_accessattempt; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.axes_accessattempt (
    id integer NOT NULL,
    user_agent character varying(255) NOT NULL,
    ip_address inet,
    username character varying(255),
    http_accept character varying(1025) NOT NULL,
    path_info character varying(255) NOT NULL,
    attempt_time timestamp with time zone NOT NULL,
    get_data text NOT NULL,
    post_data text NOT NULL,
    failures_since_start integer NOT NULL,
    CONSTRAINT axes_accessattempt_failures_since_start_check CHECK ((failures_since_start >= 0))
);


ALTER TABLE public.axes_accessattempt OWNER TO admin;

--
-- Name: axes_accessattempt_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.axes_accessattempt_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.axes_accessattempt_id_seq OWNER TO admin;

--
-- Name: axes_accessattempt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.axes_accessattempt_id_seq OWNED BY public.axes_accessattempt.id;


--
-- Name: axes_accesslog; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.axes_accesslog (
    id integer NOT NULL,
    user_agent character varying(255) NOT NULL,
    ip_address inet,
    username character varying(255),
    http_accept character varying(1025) NOT NULL,
    path_info character varying(255) NOT NULL,
    attempt_time timestamp with time zone NOT NULL,
    logout_time timestamp with time zone
);


ALTER TABLE public.axes_accesslog OWNER TO admin;

--
-- Name: axes_accesslog_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.axes_accesslog_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.axes_accesslog_id_seq OWNER TO admin;

--
-- Name: axes_accesslog_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.axes_accesslog_id_seq OWNED BY public.axes_accesslog.id;


--
-- Name: beeswax_metainstall; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.beeswax_metainstall (
    id integer NOT NULL,
    installed_example boolean NOT NULL
);


ALTER TABLE public.beeswax_metainstall OWNER TO admin;

--
-- Name: beeswax_metainstall_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.beeswax_metainstall_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.beeswax_metainstall_id_seq OWNER TO admin;

--
-- Name: beeswax_metainstall_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.beeswax_metainstall_id_seq OWNED BY public.beeswax_metainstall.id;


--
-- Name: beeswax_queryhistory; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.beeswax_queryhistory (
    id integer NOT NULL,
    query text NOT NULL,
    last_state integer NOT NULL,
    has_results boolean NOT NULL,
    submission_date timestamp with time zone NOT NULL,
    server_id character varying(1024),
    server_guid character varying(1024),
    statement_number smallint NOT NULL,
    operation_type smallint,
    modified_row_count double precision,
    log_context character varying(1024),
    server_host character varying(128) NOT NULL,
    server_port integer NOT NULL,
    server_name character varying(128) NOT NULL,
    server_type character varying(128) NOT NULL,
    query_type smallint NOT NULL,
    notify boolean NOT NULL,
    is_redacted boolean NOT NULL,
    extra text NOT NULL,
    is_cleared boolean NOT NULL,
    design_id integer,
    owner_id integer NOT NULL,
    CONSTRAINT beeswax_queryhistory_server_port_check CHECK ((server_port >= 0))
);


ALTER TABLE public.beeswax_queryhistory OWNER TO admin;

--
-- Name: beeswax_queryhistory_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.beeswax_queryhistory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.beeswax_queryhistory_id_seq OWNER TO admin;

--
-- Name: beeswax_queryhistory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.beeswax_queryhistory_id_seq OWNED BY public.beeswax_queryhistory.id;


--
-- Name: beeswax_savedquery; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.beeswax_savedquery (
    id integer NOT NULL,
    type integer NOT NULL,
    data text NOT NULL,
    name character varying(80) NOT NULL,
    "desc" text NOT NULL,
    mtime timestamp with time zone NOT NULL,
    is_auto boolean NOT NULL,
    is_trashed boolean NOT NULL,
    is_redacted boolean NOT NULL,
    owner_id integer NOT NULL
);


ALTER TABLE public.beeswax_savedquery OWNER TO admin;

--
-- Name: beeswax_savedquery_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.beeswax_savedquery_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.beeswax_savedquery_id_seq OWNER TO admin;

--
-- Name: beeswax_savedquery_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.beeswax_savedquery_id_seq OWNED BY public.beeswax_savedquery.id;


--
-- Name: beeswax_session; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.beeswax_session (
    id integer NOT NULL,
    status_code smallint NOT NULL,
    secret text NOT NULL,
    guid text NOT NULL,
    server_protocol_version smallint NOT NULL,
    last_used timestamp with time zone NOT NULL,
    application character varying(128) NOT NULL,
    properties text NOT NULL,
    owner_id integer NOT NULL,
    CONSTRAINT beeswax_session_status_code_check CHECK ((status_code >= 0))
);


ALTER TABLE public.beeswax_session OWNER TO admin;

--
-- Name: beeswax_session_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.beeswax_session_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.beeswax_session_id_seq OWNER TO admin;

--
-- Name: beeswax_session_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.beeswax_session_id_seq OWNED BY public.beeswax_session.id;


--
-- Name: defaultconfiguration_groups; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.defaultconfiguration_groups (
    id integer NOT NULL,
    defaultconfiguration_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.defaultconfiguration_groups OWNER TO admin;

--
-- Name: defaultconfiguration_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.defaultconfiguration_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.defaultconfiguration_groups_id_seq OWNER TO admin;

--
-- Name: defaultconfiguration_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.defaultconfiguration_groups_id_seq OWNED BY public.defaultconfiguration_groups.id;


--
-- Name: desktop_connector; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.desktop_connector (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    dialect character varying(32) NOT NULL,
    settings text NOT NULL,
    last_modified timestamp with time zone NOT NULL,
    interface character varying(32) NOT NULL
);


ALTER TABLE public.desktop_connector OWNER TO admin;

--
-- Name: desktop_connector_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.desktop_connector_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.desktop_connector_id_seq OWNER TO admin;

--
-- Name: desktop_connector_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.desktop_connector_id_seq OWNED BY public.desktop_connector.id;


--
-- Name: desktop_defaultconfiguration; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.desktop_defaultconfiguration (
    id integer NOT NULL,
    app character varying(32) NOT NULL,
    properties text NOT NULL,
    is_default boolean NOT NULL,
    user_id integer
);


ALTER TABLE public.desktop_defaultconfiguration OWNER TO admin;

--
-- Name: desktop_defaultconfiguration_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.desktop_defaultconfiguration_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.desktop_defaultconfiguration_id_seq OWNER TO admin;

--
-- Name: desktop_defaultconfiguration_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.desktop_defaultconfiguration_id_seq OWNED BY public.desktop_defaultconfiguration.id;


--
-- Name: desktop_document; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.desktop_document (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    last_modified timestamp with time zone NOT NULL,
    version smallint NOT NULL,
    extra text NOT NULL,
    object_id integer NOT NULL,
    content_type_id integer NOT NULL,
    owner_id integer NOT NULL,
    CONSTRAINT desktop_document_object_id_check CHECK ((object_id >= 0))
);


ALTER TABLE public.desktop_document OWNER TO admin;

--
-- Name: desktop_document2; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.desktop_document2 (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description text NOT NULL,
    uuid character varying(36) NOT NULL,
    type character varying(32) NOT NULL,
    data text NOT NULL,
    extra text NOT NULL,
    last_modified timestamp with time zone NOT NULL,
    version smallint NOT NULL,
    is_history boolean NOT NULL,
    owner_id integer NOT NULL,
    parent_directory_id integer,
    search text,
    is_trashed boolean NOT NULL,
    is_managed boolean NOT NULL,
    connector_id integer
);


ALTER TABLE public.desktop_document2 OWNER TO admin;

--
-- Name: desktop_document2_dependencies; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.desktop_document2_dependencies (
    id integer NOT NULL,
    from_document2_id integer NOT NULL,
    to_document2_id integer NOT NULL
);


ALTER TABLE public.desktop_document2_dependencies OWNER TO admin;

--
-- Name: desktop_document2_dependencies_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.desktop_document2_dependencies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.desktop_document2_dependencies_id_seq OWNER TO admin;

--
-- Name: desktop_document2_dependencies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.desktop_document2_dependencies_id_seq OWNED BY public.desktop_document2_dependencies.id;


--
-- Name: desktop_document2_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.desktop_document2_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.desktop_document2_id_seq OWNER TO admin;

--
-- Name: desktop_document2_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.desktop_document2_id_seq OWNED BY public.desktop_document2.id;


--
-- Name: desktop_document2permission; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.desktop_document2permission (
    id integer NOT NULL,
    perms character varying(10) NOT NULL,
    doc_id integer NOT NULL,
    is_link_on boolean NOT NULL
);


ALTER TABLE public.desktop_document2permission OWNER TO admin;

--
-- Name: desktop_document2permission_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.desktop_document2permission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.desktop_document2permission_id_seq OWNER TO admin;

--
-- Name: desktop_document2permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.desktop_document2permission_id_seq OWNED BY public.desktop_document2permission.id;


--
-- Name: desktop_document_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.desktop_document_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.desktop_document_id_seq OWNER TO admin;

--
-- Name: desktop_document_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.desktop_document_id_seq OWNED BY public.desktop_document.id;


--
-- Name: desktop_document_tags; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.desktop_document_tags (
    id integer NOT NULL,
    document_id integer NOT NULL,
    documenttag_id integer NOT NULL
);


ALTER TABLE public.desktop_document_tags OWNER TO admin;

--
-- Name: desktop_document_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.desktop_document_tags_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.desktop_document_tags_id_seq OWNER TO admin;

--
-- Name: desktop_document_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.desktop_document_tags_id_seq OWNED BY public.desktop_document_tags.id;


--
-- Name: desktop_documentpermission; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.desktop_documentpermission (
    id integer NOT NULL,
    perms character varying(10) NOT NULL,
    doc_id integer NOT NULL
);


ALTER TABLE public.desktop_documentpermission OWNER TO admin;

--
-- Name: desktop_documentpermission_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.desktop_documentpermission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.desktop_documentpermission_id_seq OWNER TO admin;

--
-- Name: desktop_documentpermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.desktop_documentpermission_id_seq OWNED BY public.desktop_documentpermission.id;


--
-- Name: desktop_documenttag; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.desktop_documenttag (
    id integer NOT NULL,
    tag character varying(50) NOT NULL,
    owner_id integer NOT NULL
);


ALTER TABLE public.desktop_documenttag OWNER TO admin;

--
-- Name: desktop_documenttag_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.desktop_documenttag_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.desktop_documenttag_id_seq OWNER TO admin;

--
-- Name: desktop_documenttag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.desktop_documenttag_id_seq OWNED BY public.desktop_documenttag.id;


--
-- Name: desktop_settings; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.desktop_settings (
    id integer NOT NULL,
    collect_usage boolean NOT NULL,
    tours_and_tutorials boolean NOT NULL
);


ALTER TABLE public.desktop_settings OWNER TO admin;

--
-- Name: desktop_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.desktop_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.desktop_settings_id_seq OWNER TO admin;

--
-- Name: desktop_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.desktop_settings_id_seq OWNED BY public.desktop_settings.id;


--
-- Name: desktop_userpreferences; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.desktop_userpreferences (
    id integer NOT NULL,
    key character varying(20) NOT NULL,
    value text NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.desktop_userpreferences OWNER TO admin;

--
-- Name: desktop_userpreferences_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.desktop_userpreferences_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.desktop_userpreferences_id_seq OWNER TO admin;

--
-- Name: desktop_userpreferences_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.desktop_userpreferences_id_seq OWNED BY public.desktop_userpreferences.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO admin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.django_content_type_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO admin;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO admin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.django_migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO admin;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO admin;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO admin;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.django_site_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO admin;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: documentpermission2_groups; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.documentpermission2_groups (
    id integer NOT NULL,
    document2permission_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.documentpermission2_groups OWNER TO admin;

--
-- Name: documentpermission2_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.documentpermission2_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.documentpermission2_groups_id_seq OWNER TO admin;

--
-- Name: documentpermission2_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.documentpermission2_groups_id_seq OWNED BY public.documentpermission2_groups.id;


--
-- Name: documentpermission2_users; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.documentpermission2_users (
    id integer NOT NULL,
    document2permission_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.documentpermission2_users OWNER TO admin;

--
-- Name: documentpermission2_users_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.documentpermission2_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.documentpermission2_users_id_seq OWNER TO admin;

--
-- Name: documentpermission2_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.documentpermission2_users_id_seq OWNED BY public.documentpermission2_users.id;


--
-- Name: documentpermission_groups; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.documentpermission_groups (
    id integer NOT NULL,
    documentpermission_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.documentpermission_groups OWNER TO admin;

--
-- Name: documentpermission_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.documentpermission_groups_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.documentpermission_groups_id_seq OWNER TO admin;

--
-- Name: documentpermission_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.documentpermission_groups_id_seq OWNED BY public.documentpermission_groups.id;


--
-- Name: documentpermission_users; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.documentpermission_users (
    id integer NOT NULL,
    documentpermission_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.documentpermission_users OWNER TO admin;

--
-- Name: documentpermission_users_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.documentpermission_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.documentpermission_users_id_seq OWNER TO admin;

--
-- Name: documentpermission_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.documentpermission_users_id_seq OWNED BY public.documentpermission_users.id;


--
-- Name: jobsub_checkforsetup; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.jobsub_checkforsetup (
    id integer NOT NULL,
    setup_run boolean NOT NULL,
    setup_level integer NOT NULL
);


ALTER TABLE public.jobsub_checkforsetup OWNER TO admin;

--
-- Name: jobsub_checkforsetup_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.jobsub_checkforsetup_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jobsub_checkforsetup_id_seq OWNER TO admin;

--
-- Name: jobsub_checkforsetup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.jobsub_checkforsetup_id_seq OWNED BY public.jobsub_checkforsetup.id;


--
-- Name: jobsub_jobdesign; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.jobsub_jobdesign (
    id integer NOT NULL,
    name character varying(40) NOT NULL,
    description character varying(1024) NOT NULL,
    last_modified timestamp with time zone NOT NULL,
    type character varying(128) NOT NULL,
    data text NOT NULL,
    owner_id integer NOT NULL
);


ALTER TABLE public.jobsub_jobdesign OWNER TO admin;

--
-- Name: jobsub_jobdesign_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.jobsub_jobdesign_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jobsub_jobdesign_id_seq OWNER TO admin;

--
-- Name: jobsub_jobdesign_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.jobsub_jobdesign_id_seq OWNED BY public.jobsub_jobdesign.id;


--
-- Name: jobsub_jobhistory; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.jobsub_jobhistory (
    id integer NOT NULL,
    submission_date timestamp with time zone NOT NULL,
    job_id character varying(128) NOT NULL,
    design_id integer NOT NULL,
    owner_id integer NOT NULL
);


ALTER TABLE public.jobsub_jobhistory OWNER TO admin;

--
-- Name: jobsub_jobhistory_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.jobsub_jobhistory_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jobsub_jobhistory_id_seq OWNER TO admin;

--
-- Name: jobsub_jobhistory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.jobsub_jobhistory_id_seq OWNED BY public.jobsub_jobhistory.id;


--
-- Name: jobsub_oozieaction; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.jobsub_oozieaction (
    id integer NOT NULL,
    action_type character varying(64) NOT NULL
);


ALTER TABLE public.jobsub_oozieaction OWNER TO admin;

--
-- Name: jobsub_oozieaction_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.jobsub_oozieaction_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jobsub_oozieaction_id_seq OWNER TO admin;

--
-- Name: jobsub_oozieaction_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.jobsub_oozieaction_id_seq OWNED BY public.jobsub_oozieaction.id;


--
-- Name: jobsub_ooziedesign; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.jobsub_ooziedesign (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    description character varying(1024) NOT NULL,
    last_modified timestamp with time zone NOT NULL,
    owner_id integer NOT NULL,
    root_action_id integer NOT NULL
);


ALTER TABLE public.jobsub_ooziedesign OWNER TO admin;

--
-- Name: jobsub_ooziedesign_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.jobsub_ooziedesign_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.jobsub_ooziedesign_id_seq OWNER TO admin;

--
-- Name: jobsub_ooziedesign_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.jobsub_ooziedesign_id_seq OWNED BY public.jobsub_ooziedesign.id;


--
-- Name: jobsub_ooziejavaaction; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.jobsub_ooziejavaaction (
    oozieaction_ptr_id integer NOT NULL,
    files character varying(512) NOT NULL,
    archives character varying(512) NOT NULL,
    jar_path character varying(512) NOT NULL,
    main_class character varying(256) NOT NULL,
    args text NOT NULL,
    java_opts character varying(256) NOT NULL,
    job_properties text NOT NULL
);


ALTER TABLE public.jobsub_ooziejavaaction OWNER TO admin;

--
-- Name: jobsub_ooziemapreduceaction; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.jobsub_ooziemapreduceaction (
    oozieaction_ptr_id integer NOT NULL,
    files character varying(512) NOT NULL,
    archives character varying(512) NOT NULL,
    job_properties text NOT NULL,
    jar_path character varying(512) NOT NULL
);


ALTER TABLE public.jobsub_ooziemapreduceaction OWNER TO admin;

--
-- Name: jobsub_ooziestreamingaction; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.jobsub_ooziestreamingaction (
    oozieaction_ptr_id integer NOT NULL,
    files character varying(512) NOT NULL,
    archives character varying(512) NOT NULL,
    job_properties text NOT NULL,
    mapper character varying(512) NOT NULL,
    reducer character varying(512) NOT NULL
);


ALTER TABLE public.jobsub_ooziestreamingaction OWNER TO admin;

--
-- Name: oozie_bundle; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_bundle (
    job_ptr_id integer NOT NULL,
    kick_off_time timestamp with time zone NOT NULL
);


ALTER TABLE public.oozie_bundle OWNER TO admin;

--
-- Name: oozie_bundledcoordinator; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_bundledcoordinator (
    id integer NOT NULL,
    parameters text NOT NULL,
    bundle_id integer NOT NULL,
    coordinator_id integer NOT NULL
);


ALTER TABLE public.oozie_bundledcoordinator OWNER TO admin;

--
-- Name: oozie_bundledcoordinator_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.oozie_bundledcoordinator_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oozie_bundledcoordinator_id_seq OWNER TO admin;

--
-- Name: oozie_bundledcoordinator_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.oozie_bundledcoordinator_id_seq OWNED BY public.oozie_bundledcoordinator.id;


--
-- Name: oozie_coordinator; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_coordinator (
    job_ptr_id integer NOT NULL,
    frequency_number smallint NOT NULL,
    frequency_unit character varying(20) NOT NULL,
    timezone character varying(32) NOT NULL,
    start timestamp with time zone NOT NULL,
    "end" timestamp with time zone NOT NULL,
    timeout smallint,
    concurrency smallint,
    execution character varying(10),
    throttle smallint,
    job_properties text NOT NULL,
    coordinatorworkflow_id integer,
    CONSTRAINT oozie_coordinator_concurrency_check CHECK ((concurrency >= 0)),
    CONSTRAINT oozie_coordinator_throttle_check CHECK ((throttle >= 0))
);


ALTER TABLE public.oozie_coordinator OWNER TO admin;

--
-- Name: oozie_datainput; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_datainput (
    id integer NOT NULL,
    name character varying(40) NOT NULL,
    dataset_id integer NOT NULL,
    coordinator_id integer NOT NULL
);


ALTER TABLE public.oozie_datainput OWNER TO admin;

--
-- Name: oozie_datainput_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.oozie_datainput_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oozie_datainput_id_seq OWNER TO admin;

--
-- Name: oozie_datainput_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.oozie_datainput_id_seq OWNED BY public.oozie_datainput.id;


--
-- Name: oozie_dataoutput; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_dataoutput (
    id integer NOT NULL,
    name character varying(40) NOT NULL,
    dataset_id integer NOT NULL,
    coordinator_id integer NOT NULL
);


ALTER TABLE public.oozie_dataoutput OWNER TO admin;

--
-- Name: oozie_dataoutput_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.oozie_dataoutput_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oozie_dataoutput_id_seq OWNER TO admin;

--
-- Name: oozie_dataoutput_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.oozie_dataoutput_id_seq OWNED BY public.oozie_dataoutput.id;


--
-- Name: oozie_dataset; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_dataset (
    id integer NOT NULL,
    name character varying(40) NOT NULL,
    description character varying(1024) NOT NULL,
    start timestamp with time zone NOT NULL,
    frequency_number smallint NOT NULL,
    frequency_unit character varying(20) NOT NULL,
    uri character varying(1024) NOT NULL,
    timezone character varying(32) NOT NULL,
    done_flag character varying(64) NOT NULL,
    instance_choice character varying(10) NOT NULL,
    advanced_start_instance character varying(128) NOT NULL,
    advanced_end_instance character varying(128) NOT NULL,
    coordinator_id integer NOT NULL
);


ALTER TABLE public.oozie_dataset OWNER TO admin;

--
-- Name: oozie_dataset_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.oozie_dataset_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oozie_dataset_id_seq OWNER TO admin;

--
-- Name: oozie_dataset_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.oozie_dataset_id_seq OWNED BY public.oozie_dataset.id;


--
-- Name: oozie_decision; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_decision (
    node_ptr_id integer NOT NULL
);


ALTER TABLE public.oozie_decision OWNER TO admin;

--
-- Name: oozie_decisionend; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_decisionend (
    node_ptr_id integer NOT NULL
);


ALTER TABLE public.oozie_decisionend OWNER TO admin;

--
-- Name: oozie_distcp; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_distcp (
    node_ptr_id integer NOT NULL,
    params text NOT NULL,
    job_properties text NOT NULL,
    prepares text NOT NULL,
    job_xml character varying(512) NOT NULL
);


ALTER TABLE public.oozie_distcp OWNER TO admin;

--
-- Name: oozie_email; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_email (
    node_ptr_id integer NOT NULL,
    "to" text NOT NULL,
    cc text NOT NULL,
    subject text NOT NULL,
    body text NOT NULL
);


ALTER TABLE public.oozie_email OWNER TO admin;

--
-- Name: oozie_end; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_end (
    node_ptr_id integer NOT NULL
);


ALTER TABLE public.oozie_end OWNER TO admin;

--
-- Name: oozie_fork; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_fork (
    node_ptr_id integer NOT NULL
);


ALTER TABLE public.oozie_fork OWNER TO admin;

--
-- Name: oozie_fs; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_fs (
    node_ptr_id integer NOT NULL,
    deletes text NOT NULL,
    mkdirs text NOT NULL,
    moves text NOT NULL,
    chmods text NOT NULL,
    touchzs text NOT NULL
);


ALTER TABLE public.oozie_fs OWNER TO admin;

--
-- Name: oozie_generic; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_generic (
    node_ptr_id integer NOT NULL,
    xml text NOT NULL
);


ALTER TABLE public.oozie_generic OWNER TO admin;

--
-- Name: oozie_history; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_history (
    id integer NOT NULL,
    submission_date timestamp with time zone NOT NULL,
    oozie_job_id character varying(128) NOT NULL,
    properties text NOT NULL,
    submitter_id integer NOT NULL,
    job_id integer NOT NULL
);


ALTER TABLE public.oozie_history OWNER TO admin;

--
-- Name: oozie_history_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.oozie_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oozie_history_id_seq OWNER TO admin;

--
-- Name: oozie_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.oozie_history_id_seq OWNED BY public.oozie_history.id;


--
-- Name: oozie_hive; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_hive (
    node_ptr_id integer NOT NULL,
    script_path character varying(256) NOT NULL,
    params text NOT NULL,
    files text NOT NULL,
    archives text NOT NULL,
    job_properties text NOT NULL,
    prepares text NOT NULL,
    job_xml character varying(512) NOT NULL
);


ALTER TABLE public.oozie_hive OWNER TO admin;

--
-- Name: oozie_java; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_java (
    node_ptr_id integer NOT NULL,
    files text NOT NULL,
    archives text NOT NULL,
    jar_path character varying(512) NOT NULL,
    main_class character varying(256) NOT NULL,
    args text NOT NULL,
    java_opts character varying(256) NOT NULL,
    job_properties text NOT NULL,
    prepares text NOT NULL,
    job_xml character varying(512) NOT NULL,
    capture_output boolean NOT NULL
);


ALTER TABLE public.oozie_java OWNER TO admin;

--
-- Name: oozie_job; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_job (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(1024) NOT NULL,
    last_modified timestamp with time zone NOT NULL,
    schema_version character varying(128) NOT NULL,
    deployment_dir character varying(1024) NOT NULL,
    is_shared boolean NOT NULL,
    parameters text NOT NULL,
    is_trashed boolean NOT NULL,
    data text NOT NULL,
    owner_id integer NOT NULL
);


ALTER TABLE public.oozie_job OWNER TO admin;

--
-- Name: oozie_job_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.oozie_job_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oozie_job_id_seq OWNER TO admin;

--
-- Name: oozie_job_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.oozie_job_id_seq OWNED BY public.oozie_job.id;


--
-- Name: oozie_join; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_join (
    node_ptr_id integer NOT NULL
);


ALTER TABLE public.oozie_join OWNER TO admin;

--
-- Name: oozie_kill; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_kill (
    node_ptr_id integer NOT NULL,
    message character varying(256) NOT NULL
);


ALTER TABLE public.oozie_kill OWNER TO admin;

--
-- Name: oozie_link; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_link (
    id integer NOT NULL,
    name character varying(40) NOT NULL,
    comment character varying(1024) NOT NULL,
    child_id integer NOT NULL,
    parent_id integer NOT NULL
);


ALTER TABLE public.oozie_link OWNER TO admin;

--
-- Name: oozie_link_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.oozie_link_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oozie_link_id_seq OWNER TO admin;

--
-- Name: oozie_link_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.oozie_link_id_seq OWNED BY public.oozie_link.id;


--
-- Name: oozie_mapreduce; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_mapreduce (
    node_ptr_id integer NOT NULL,
    files text NOT NULL,
    archives text NOT NULL,
    job_properties text NOT NULL,
    jar_path character varying(512) NOT NULL,
    prepares text NOT NULL,
    job_xml character varying(512) NOT NULL
);


ALTER TABLE public.oozie_mapreduce OWNER TO admin;

--
-- Name: oozie_node; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_node (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    description character varying(1024) NOT NULL,
    node_type character varying(64) NOT NULL,
    data text NOT NULL,
    workflow_id integer NOT NULL
);


ALTER TABLE public.oozie_node OWNER TO admin;

--
-- Name: oozie_node_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.oozie_node_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.oozie_node_id_seq OWNER TO admin;

--
-- Name: oozie_node_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.oozie_node_id_seq OWNED BY public.oozie_node.id;


--
-- Name: oozie_pig; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_pig (
    node_ptr_id integer NOT NULL,
    script_path character varying(256) NOT NULL,
    params text NOT NULL,
    files text NOT NULL,
    archives text NOT NULL,
    job_properties text NOT NULL,
    prepares text NOT NULL,
    job_xml character varying(512) NOT NULL
);


ALTER TABLE public.oozie_pig OWNER TO admin;

--
-- Name: oozie_shell; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_shell (
    node_ptr_id integer NOT NULL,
    command character varying(256) NOT NULL,
    params text NOT NULL,
    files text NOT NULL,
    archives text NOT NULL,
    job_properties text NOT NULL,
    prepares text NOT NULL,
    job_xml character varying(512) NOT NULL,
    capture_output boolean NOT NULL
);


ALTER TABLE public.oozie_shell OWNER TO admin;

--
-- Name: oozie_sqoop; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_sqoop (
    node_ptr_id integer NOT NULL,
    script_path text NOT NULL,
    params text NOT NULL,
    files text NOT NULL,
    archives text NOT NULL,
    job_properties text NOT NULL,
    prepares text NOT NULL,
    job_xml character varying(512) NOT NULL
);


ALTER TABLE public.oozie_sqoop OWNER TO admin;

--
-- Name: oozie_ssh; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_ssh (
    node_ptr_id integer NOT NULL,
    "user" character varying(64) NOT NULL,
    host character varying(256) NOT NULL,
    command character varying(256) NOT NULL,
    params text NOT NULL,
    capture_output boolean NOT NULL
);


ALTER TABLE public.oozie_ssh OWNER TO admin;

--
-- Name: oozie_start; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_start (
    node_ptr_id integer NOT NULL
);


ALTER TABLE public.oozie_start OWNER TO admin;

--
-- Name: oozie_streaming; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_streaming (
    node_ptr_id integer NOT NULL,
    files text NOT NULL,
    archives text NOT NULL,
    job_properties text NOT NULL,
    mapper character varying(512) NOT NULL,
    reducer character varying(512) NOT NULL
);


ALTER TABLE public.oozie_streaming OWNER TO admin;

--
-- Name: oozie_subworkflow; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_subworkflow (
    node_ptr_id integer NOT NULL,
    propagate_configuration boolean NOT NULL,
    job_properties text NOT NULL,
    sub_workflow_id integer
);


ALTER TABLE public.oozie_subworkflow OWNER TO admin;

--
-- Name: oozie_workflow; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.oozie_workflow (
    job_ptr_id integer NOT NULL,
    is_single boolean NOT NULL,
    job_xml character varying(512) NOT NULL,
    job_properties text NOT NULL,
    managed boolean NOT NULL,
    end_id integer,
    start_id integer
);


ALTER TABLE public.oozie_workflow OWNER TO admin;

--
-- Name: pig_document; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.pig_document (
    id integer NOT NULL,
    is_design boolean NOT NULL,
    owner_id integer NOT NULL
);


ALTER TABLE public.pig_document OWNER TO admin;

--
-- Name: pig_document_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.pig_document_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pig_document_id_seq OWNER TO admin;

--
-- Name: pig_document_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.pig_document_id_seq OWNED BY public.pig_document.id;


--
-- Name: pig_pigscript; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.pig_pigscript (
    document_ptr_id integer NOT NULL,
    data text NOT NULL
);


ALTER TABLE public.pig_pigscript OWNER TO admin;

--
-- Name: useradmin_grouppermission; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.useradmin_grouppermission (
    id integer NOT NULL,
    group_id integer NOT NULL,
    hue_permission_id integer NOT NULL
);


ALTER TABLE public.useradmin_grouppermission OWNER TO admin;

--
-- Name: useradmin_grouppermission_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.useradmin_grouppermission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.useradmin_grouppermission_id_seq OWNER TO admin;

--
-- Name: useradmin_grouppermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.useradmin_grouppermission_id_seq OWNED BY public.useradmin_grouppermission.id;


--
-- Name: useradmin_huepermission; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.useradmin_huepermission (
    id integer NOT NULL,
    app character varying(30) NOT NULL,
    action character varying(100) NOT NULL,
    description character varying(255) NOT NULL
);


ALTER TABLE public.useradmin_huepermission OWNER TO admin;

--
-- Name: useradmin_huepermission_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.useradmin_huepermission_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.useradmin_huepermission_id_seq OWNER TO admin;

--
-- Name: useradmin_huepermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.useradmin_huepermission_id_seq OWNED BY public.useradmin_huepermission.id;


--
-- Name: useradmin_ldapgroup; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.useradmin_ldapgroup (
    id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.useradmin_ldapgroup OWNER TO admin;

--
-- Name: useradmin_ldapgroup_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.useradmin_ldapgroup_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.useradmin_ldapgroup_id_seq OWNER TO admin;

--
-- Name: useradmin_ldapgroup_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.useradmin_ldapgroup_id_seq OWNED BY public.useradmin_ldapgroup.id;


--
-- Name: useradmin_userprofile; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.useradmin_userprofile (
    id integer NOT NULL,
    home_directory character varying(1024),
    creation_method character varying(64) NOT NULL,
    first_login boolean NOT NULL,
    last_activity timestamp with time zone NOT NULL,
    user_id integer NOT NULL,
    json_data text NOT NULL,
    hostname character varying(255)
);


ALTER TABLE public.useradmin_userprofile OWNER TO admin;

--
-- Name: useradmin_userprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.useradmin_userprofile_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.useradmin_userprofile_id_seq OWNER TO admin;

--
-- Name: useradmin_userprofile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.useradmin_userprofile_id_seq OWNED BY public.useradmin_userprofile.id;


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: axes_accessattempt id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.axes_accessattempt ALTER COLUMN id SET DEFAULT nextval('public.axes_accessattempt_id_seq'::regclass);


--
-- Name: axes_accesslog id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.axes_accesslog ALTER COLUMN id SET DEFAULT nextval('public.axes_accesslog_id_seq'::regclass);


--
-- Name: beeswax_metainstall id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.beeswax_metainstall ALTER COLUMN id SET DEFAULT nextval('public.beeswax_metainstall_id_seq'::regclass);


--
-- Name: beeswax_queryhistory id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.beeswax_queryhistory ALTER COLUMN id SET DEFAULT nextval('public.beeswax_queryhistory_id_seq'::regclass);


--
-- Name: beeswax_savedquery id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.beeswax_savedquery ALTER COLUMN id SET DEFAULT nextval('public.beeswax_savedquery_id_seq'::regclass);


--
-- Name: beeswax_session id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.beeswax_session ALTER COLUMN id SET DEFAULT nextval('public.beeswax_session_id_seq'::regclass);


--
-- Name: defaultconfiguration_groups id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.defaultconfiguration_groups ALTER COLUMN id SET DEFAULT nextval('public.defaultconfiguration_groups_id_seq'::regclass);


--
-- Name: desktop_connector id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_connector ALTER COLUMN id SET DEFAULT nextval('public.desktop_connector_id_seq'::regclass);


--
-- Name: desktop_defaultconfiguration id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_defaultconfiguration ALTER COLUMN id SET DEFAULT nextval('public.desktop_defaultconfiguration_id_seq'::regclass);


--
-- Name: desktop_document id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document ALTER COLUMN id SET DEFAULT nextval('public.desktop_document_id_seq'::regclass);


--
-- Name: desktop_document2 id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document2 ALTER COLUMN id SET DEFAULT nextval('public.desktop_document2_id_seq'::regclass);


--
-- Name: desktop_document2_dependencies id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document2_dependencies ALTER COLUMN id SET DEFAULT nextval('public.desktop_document2_dependencies_id_seq'::regclass);


--
-- Name: desktop_document2permission id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document2permission ALTER COLUMN id SET DEFAULT nextval('public.desktop_document2permission_id_seq'::regclass);


--
-- Name: desktop_document_tags id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document_tags ALTER COLUMN id SET DEFAULT nextval('public.desktop_document_tags_id_seq'::regclass);


--
-- Name: desktop_documentpermission id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_documentpermission ALTER COLUMN id SET DEFAULT nextval('public.desktop_documentpermission_id_seq'::regclass);


--
-- Name: desktop_documenttag id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_documenttag ALTER COLUMN id SET DEFAULT nextval('public.desktop_documenttag_id_seq'::regclass);


--
-- Name: desktop_settings id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_settings ALTER COLUMN id SET DEFAULT nextval('public.desktop_settings_id_seq'::regclass);


--
-- Name: desktop_userpreferences id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_userpreferences ALTER COLUMN id SET DEFAULT nextval('public.desktop_userpreferences_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: documentpermission2_groups id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission2_groups ALTER COLUMN id SET DEFAULT nextval('public.documentpermission2_groups_id_seq'::regclass);


--
-- Name: documentpermission2_users id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission2_users ALTER COLUMN id SET DEFAULT nextval('public.documentpermission2_users_id_seq'::regclass);


--
-- Name: documentpermission_groups id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission_groups ALTER COLUMN id SET DEFAULT nextval('public.documentpermission_groups_id_seq'::regclass);


--
-- Name: documentpermission_users id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission_users ALTER COLUMN id SET DEFAULT nextval('public.documentpermission_users_id_seq'::regclass);


--
-- Name: jobsub_checkforsetup id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_checkforsetup ALTER COLUMN id SET DEFAULT nextval('public.jobsub_checkforsetup_id_seq'::regclass);


--
-- Name: jobsub_jobdesign id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_jobdesign ALTER COLUMN id SET DEFAULT nextval('public.jobsub_jobdesign_id_seq'::regclass);


--
-- Name: jobsub_jobhistory id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_jobhistory ALTER COLUMN id SET DEFAULT nextval('public.jobsub_jobhistory_id_seq'::regclass);


--
-- Name: jobsub_oozieaction id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_oozieaction ALTER COLUMN id SET DEFAULT nextval('public.jobsub_oozieaction_id_seq'::regclass);


--
-- Name: jobsub_ooziedesign id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_ooziedesign ALTER COLUMN id SET DEFAULT nextval('public.jobsub_ooziedesign_id_seq'::regclass);


--
-- Name: oozie_bundledcoordinator id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_bundledcoordinator ALTER COLUMN id SET DEFAULT nextval('public.oozie_bundledcoordinator_id_seq'::regclass);


--
-- Name: oozie_datainput id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_datainput ALTER COLUMN id SET DEFAULT nextval('public.oozie_datainput_id_seq'::regclass);


--
-- Name: oozie_dataoutput id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_dataoutput ALTER COLUMN id SET DEFAULT nextval('public.oozie_dataoutput_id_seq'::regclass);


--
-- Name: oozie_dataset id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_dataset ALTER COLUMN id SET DEFAULT nextval('public.oozie_dataset_id_seq'::regclass);


--
-- Name: oozie_history id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_history ALTER COLUMN id SET DEFAULT nextval('public.oozie_history_id_seq'::regclass);


--
-- Name: oozie_job id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_job ALTER COLUMN id SET DEFAULT nextval('public.oozie_job_id_seq'::regclass);


--
-- Name: oozie_link id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_link ALTER COLUMN id SET DEFAULT nextval('public.oozie_link_id_seq'::regclass);


--
-- Name: oozie_node id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_node ALTER COLUMN id SET DEFAULT nextval('public.oozie_node_id_seq'::regclass);


--
-- Name: pig_document id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.pig_document ALTER COLUMN id SET DEFAULT nextval('public.pig_document_id_seq'::regclass);


--
-- Name: useradmin_grouppermission id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.useradmin_grouppermission ALTER COLUMN id SET DEFAULT nextval('public.useradmin_grouppermission_id_seq'::regclass);


--
-- Name: useradmin_huepermission id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.useradmin_huepermission ALTER COLUMN id SET DEFAULT nextval('public.useradmin_huepermission_id_seq'::regclass);


--
-- Name: useradmin_ldapgroup id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.useradmin_ldapgroup ALTER COLUMN id SET DEFAULT nextval('public.useradmin_ldapgroup_id_seq'::regclass);


--
-- Name: useradmin_userprofile id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.useradmin_userprofile ALTER COLUMN id SET DEFAULT nextval('public.useradmin_userprofile_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3895.dat

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3897.dat

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3893.dat

--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3899.dat

--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3901.dat

--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3903.dat

--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3904.dat

--
-- Data for Name: axes_accessattempt; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3906.dat

--
-- Data for Name: axes_accesslog; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3908.dat

--
-- Data for Name: beeswax_metainstall; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3910.dat

--
-- Data for Name: beeswax_queryhistory; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3912.dat

--
-- Data for Name: beeswax_savedquery; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3914.dat

--
-- Data for Name: beeswax_session; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3916.dat

--
-- Data for Name: defaultconfiguration_groups; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3946.dat

--
-- Data for Name: desktop_connector; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3948.dat

--
-- Data for Name: desktop_defaultconfiguration; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3944.dat

--
-- Data for Name: desktop_document; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3918.dat

--
-- Data for Name: desktop_document2; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3920.dat

--
-- Data for Name: desktop_document2_dependencies; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3922.dat

--
-- Data for Name: desktop_document2permission; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3924.dat

--
-- Data for Name: desktop_document_tags; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3942.dat

--
-- Data for Name: desktop_documentpermission; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3928.dat

--
-- Data for Name: desktop_documenttag; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3932.dat

--
-- Data for Name: desktop_settings; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3934.dat

--
-- Data for Name: desktop_userpreferences; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3936.dat

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3891.dat

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3889.dat

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/4004.dat

--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/4006.dat

--
-- Data for Name: documentpermission2_groups; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3926.dat

--
-- Data for Name: documentpermission2_users; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3940.dat

--
-- Data for Name: documentpermission_groups; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3930.dat

--
-- Data for Name: documentpermission_users; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3938.dat

--
-- Data for Name: jobsub_checkforsetup; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3950.dat

--
-- Data for Name: jobsub_jobdesign; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3952.dat

--
-- Data for Name: jobsub_jobhistory; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3954.dat

--
-- Data for Name: jobsub_oozieaction; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3956.dat

--
-- Data for Name: jobsub_ooziedesign; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3958.dat

--
-- Data for Name: jobsub_ooziejavaaction; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3959.dat

--
-- Data for Name: jobsub_ooziemapreduceaction; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3960.dat

--
-- Data for Name: jobsub_ooziestreamingaction; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3961.dat

--
-- Data for Name: oozie_bundle; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3978.dat

--
-- Data for Name: oozie_bundledcoordinator; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3963.dat

--
-- Data for Name: oozie_coordinator; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3979.dat

--
-- Data for Name: oozie_datainput; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3965.dat

--
-- Data for Name: oozie_dataoutput; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3967.dat

--
-- Data for Name: oozie_dataset; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3969.dat

--
-- Data for Name: oozie_decision; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3980.dat

--
-- Data for Name: oozie_decisionend; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3981.dat

--
-- Data for Name: oozie_distcp; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3982.dat

--
-- Data for Name: oozie_email; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3983.dat

--
-- Data for Name: oozie_end; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3984.dat

--
-- Data for Name: oozie_fork; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3985.dat

--
-- Data for Name: oozie_fs; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3986.dat

--
-- Data for Name: oozie_generic; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3987.dat

--
-- Data for Name: oozie_history; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3971.dat

--
-- Data for Name: oozie_hive; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3988.dat

--
-- Data for Name: oozie_java; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3989.dat

--
-- Data for Name: oozie_job; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3973.dat

--
-- Data for Name: oozie_join; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3990.dat

--
-- Data for Name: oozie_kill; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3991.dat

--
-- Data for Name: oozie_link; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3975.dat

--
-- Data for Name: oozie_mapreduce; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3992.dat

--
-- Data for Name: oozie_node; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3977.dat

--
-- Data for Name: oozie_pig; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3993.dat

--
-- Data for Name: oozie_shell; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3994.dat

--
-- Data for Name: oozie_sqoop; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3995.dat

--
-- Data for Name: oozie_ssh; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3996.dat

--
-- Data for Name: oozie_start; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3997.dat

--
-- Data for Name: oozie_streaming; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3998.dat

--
-- Data for Name: oozie_subworkflow; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3999.dat

--
-- Data for Name: oozie_workflow; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/4000.dat

--
-- Data for Name: pig_document; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/4002.dat

--
-- Data for Name: pig_pigscript; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/4003.dat

--
-- Data for Name: useradmin_grouppermission; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/4008.dat

--
-- Data for Name: useradmin_huepermission; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/4010.dat

--
-- Data for Name: useradmin_ldapgroup; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/4012.dat

--
-- Data for Name: useradmin_userprofile; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/4014.dat

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, true);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 284, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 2, true);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 2, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: axes_accessattempt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.axes_accessattempt_id_seq', 5, true);


--
-- Name: axes_accesslog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.axes_accesslog_id_seq', 11, true);


--
-- Name: beeswax_metainstall_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.beeswax_metainstall_id_seq', 1, false);


--
-- Name: beeswax_queryhistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.beeswax_queryhistory_id_seq', 1, false);


--
-- Name: beeswax_savedquery_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.beeswax_savedquery_id_seq', 1, false);


--
-- Name: beeswax_session_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.beeswax_session_id_seq', 136, true);


--
-- Name: defaultconfiguration_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.defaultconfiguration_groups_id_seq', 1, false);


--
-- Name: desktop_connector_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.desktop_connector_id_seq', 1, false);


--
-- Name: desktop_defaultconfiguration_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.desktop_defaultconfiguration_id_seq', 1, false);


--
-- Name: desktop_document2_dependencies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.desktop_document2_dependencies_id_seq', 1, false);


--
-- Name: desktop_document2_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.desktop_document2_id_seq', 143, true);


--
-- Name: desktop_document2permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.desktop_document2permission_id_seq', 1, false);


--
-- Name: desktop_document_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.desktop_document_id_seq', 139, true);


--
-- Name: desktop_document_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.desktop_document_tags_id_seq', 139, true);


--
-- Name: desktop_documentpermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.desktop_documentpermission_id_seq', 1, false);


--
-- Name: desktop_documenttag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.desktop_documenttag_id_seq', 2, true);


--
-- Name: desktop_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.desktop_settings_id_seq', 1, false);


--
-- Name: desktop_userpreferences_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.desktop_userpreferences_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 71, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 58, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.django_site_id_seq', 1, true);


--
-- Name: documentpermission2_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.documentpermission2_groups_id_seq', 1, false);


--
-- Name: documentpermission2_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.documentpermission2_users_id_seq', 1, false);


--
-- Name: documentpermission_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.documentpermission_groups_id_seq', 1, false);


--
-- Name: documentpermission_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.documentpermission_users_id_seq', 1, false);


--
-- Name: jobsub_checkforsetup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.jobsub_checkforsetup_id_seq', 1, false);


--
-- Name: jobsub_jobdesign_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.jobsub_jobdesign_id_seq', 1, false);


--
-- Name: jobsub_jobhistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.jobsub_jobhistory_id_seq', 1, false);


--
-- Name: jobsub_oozieaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.jobsub_oozieaction_id_seq', 1, false);


--
-- Name: jobsub_ooziedesign_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.jobsub_ooziedesign_id_seq', 1, false);


--
-- Name: oozie_bundledcoordinator_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.oozie_bundledcoordinator_id_seq', 1, false);


--
-- Name: oozie_datainput_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.oozie_datainput_id_seq', 1, false);


--
-- Name: oozie_dataoutput_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.oozie_dataoutput_id_seq', 1, false);


--
-- Name: oozie_dataset_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.oozie_dataset_id_seq', 1, false);


--
-- Name: oozie_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.oozie_history_id_seq', 1, false);


--
-- Name: oozie_job_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.oozie_job_id_seq', 1, false);


--
-- Name: oozie_link_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.oozie_link_id_seq', 1, false);


--
-- Name: oozie_node_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.oozie_node_id_seq', 1, false);


--
-- Name: pig_document_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.pig_document_id_seq', 1, false);


--
-- Name: useradmin_grouppermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.useradmin_grouppermission_id_seq', 25, true);


--
-- Name: useradmin_huepermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.useradmin_huepermission_id_seq', 34, true);


--
-- Name: useradmin_ldapgroup_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.useradmin_ldapgroup_id_seq', 1, false);


--
-- Name: useradmin_userprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.useradmin_userprofile_id_seq', 2, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: authtoken_token authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- Name: authtoken_token authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- Name: axes_accessattempt axes_accessattempt_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.axes_accessattempt
    ADD CONSTRAINT axes_accessattempt_pkey PRIMARY KEY (id);


--
-- Name: axes_accesslog axes_accesslog_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.axes_accesslog
    ADD CONSTRAINT axes_accesslog_pkey PRIMARY KEY (id);


--
-- Name: beeswax_metainstall beeswax_metainstall_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.beeswax_metainstall
    ADD CONSTRAINT beeswax_metainstall_pkey PRIMARY KEY (id);


--
-- Name: beeswax_queryhistory beeswax_queryhistory_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.beeswax_queryhistory
    ADD CONSTRAINT beeswax_queryhistory_pkey PRIMARY KEY (id);


--
-- Name: beeswax_savedquery beeswax_savedquery_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.beeswax_savedquery
    ADD CONSTRAINT beeswax_savedquery_pkey PRIMARY KEY (id);


--
-- Name: beeswax_session beeswax_session_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.beeswax_session
    ADD CONSTRAINT beeswax_session_pkey PRIMARY KEY (id);


--
-- Name: defaultconfiguration_groups defaultconfiguration_gro_defaultconfiguration_id__89a9cd30_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.defaultconfiguration_groups
    ADD CONSTRAINT defaultconfiguration_gro_defaultconfiguration_id__89a9cd30_uniq UNIQUE (defaultconfiguration_id, group_id);


--
-- Name: defaultconfiguration_groups defaultconfiguration_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.defaultconfiguration_groups
    ADD CONSTRAINT defaultconfiguration_groups_pkey PRIMARY KEY (id);


--
-- Name: desktop_connector desktop_connector_name_0a0d3fbc_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_connector
    ADD CONSTRAINT desktop_connector_name_0a0d3fbc_uniq UNIQUE (name);


--
-- Name: desktop_connector desktop_connector_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_connector
    ADD CONSTRAINT desktop_connector_pkey PRIMARY KEY (id);


--
-- Name: desktop_defaultconfiguration desktop_defaultconfiguration_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_defaultconfiguration
    ADD CONSTRAINT desktop_defaultconfiguration_pkey PRIMARY KEY (id);


--
-- Name: desktop_document2_dependencies desktop_document2_depend_from_document2_id_to_doc_e8e0aebc_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document2_dependencies
    ADD CONSTRAINT desktop_document2_depend_from_document2_id_to_doc_e8e0aebc_uniq UNIQUE (from_document2_id, to_document2_id);


--
-- Name: desktop_document2_dependencies desktop_document2_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document2_dependencies
    ADD CONSTRAINT desktop_document2_dependencies_pkey PRIMARY KEY (id);


--
-- Name: desktop_document2 desktop_document2_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document2
    ADD CONSTRAINT desktop_document2_pkey PRIMARY KEY (id);


--
-- Name: desktop_document2 desktop_document2_uuid_version_is_history_f449ad78_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document2
    ADD CONSTRAINT desktop_document2_uuid_version_is_history_f449ad78_uniq UNIQUE (uuid, version, is_history);


--
-- Name: desktop_document2permission desktop_document2permission_doc_id_perms_5a4d2ad8_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document2permission
    ADD CONSTRAINT desktop_document2permission_doc_id_perms_5a4d2ad8_uniq UNIQUE (doc_id, perms);


--
-- Name: desktop_document2permission desktop_document2permission_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document2permission
    ADD CONSTRAINT desktop_document2permission_pkey PRIMARY KEY (id);


--
-- Name: desktop_document desktop_document_content_type_id_object_id_af1b9053_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document
    ADD CONSTRAINT desktop_document_content_type_id_object_id_af1b9053_uniq UNIQUE (content_type_id, object_id);


--
-- Name: desktop_document desktop_document_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document
    ADD CONSTRAINT desktop_document_pkey PRIMARY KEY (id);


--
-- Name: desktop_document_tags desktop_document_tags_document_id_documenttag_id_b89a0f94_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document_tags
    ADD CONSTRAINT desktop_document_tags_document_id_documenttag_id_b89a0f94_uniq UNIQUE (document_id, documenttag_id);


--
-- Name: desktop_document_tags desktop_document_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document_tags
    ADD CONSTRAINT desktop_document_tags_pkey PRIMARY KEY (id);


--
-- Name: desktop_documentpermission desktop_documentpermission_doc_id_perms_e898a5e1_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_documentpermission
    ADD CONSTRAINT desktop_documentpermission_doc_id_perms_e898a5e1_uniq UNIQUE (doc_id, perms);


--
-- Name: desktop_documentpermission desktop_documentpermission_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_documentpermission
    ADD CONSTRAINT desktop_documentpermission_pkey PRIMARY KEY (id);


--
-- Name: desktop_documenttag desktop_documenttag_owner_id_tag_040d0073_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_documenttag
    ADD CONSTRAINT desktop_documenttag_owner_id_tag_040d0073_uniq UNIQUE (owner_id, tag);


--
-- Name: desktop_documenttag desktop_documenttag_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_documenttag
    ADD CONSTRAINT desktop_documenttag_pkey PRIMARY KEY (id);


--
-- Name: desktop_settings desktop_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_settings
    ADD CONSTRAINT desktop_settings_pkey PRIMARY KEY (id);


--
-- Name: desktop_userpreferences desktop_userpreferences_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_userpreferences
    ADD CONSTRAINT desktop_userpreferences_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: documentpermission2_groups documentpermission2_grou_document2permission_id_g_b82724d9_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission2_groups
    ADD CONSTRAINT documentpermission2_grou_document2permission_id_g_b82724d9_uniq UNIQUE (document2permission_id, group_id);


--
-- Name: documentpermission2_groups documentpermission2_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission2_groups
    ADD CONSTRAINT documentpermission2_groups_pkey PRIMARY KEY (id);


--
-- Name: documentpermission2_users documentpermission2_user_document2permission_id_u_66ccf253_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission2_users
    ADD CONSTRAINT documentpermission2_user_document2permission_id_u_66ccf253_uniq UNIQUE (document2permission_id, user_id);


--
-- Name: documentpermission2_users documentpermission2_users_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission2_users
    ADD CONSTRAINT documentpermission2_users_pkey PRIMARY KEY (id);


--
-- Name: documentpermission_groups documentpermission_group_documentpermission_id_gr_b617df3f_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission_groups
    ADD CONSTRAINT documentpermission_group_documentpermission_id_gr_b617df3f_uniq UNIQUE (documentpermission_id, group_id);


--
-- Name: documentpermission_groups documentpermission_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission_groups
    ADD CONSTRAINT documentpermission_groups_pkey PRIMARY KEY (id);


--
-- Name: documentpermission_users documentpermission_users_documentpermission_id_us_b0be31ca_uniq; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission_users
    ADD CONSTRAINT documentpermission_users_documentpermission_id_us_b0be31ca_uniq UNIQUE (documentpermission_id, user_id);


--
-- Name: documentpermission_users documentpermission_users_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission_users
    ADD CONSTRAINT documentpermission_users_pkey PRIMARY KEY (id);


--
-- Name: jobsub_checkforsetup jobsub_checkforsetup_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_checkforsetup
    ADD CONSTRAINT jobsub_checkforsetup_pkey PRIMARY KEY (id);


--
-- Name: jobsub_jobdesign jobsub_jobdesign_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_jobdesign
    ADD CONSTRAINT jobsub_jobdesign_pkey PRIMARY KEY (id);


--
-- Name: jobsub_jobhistory jobsub_jobhistory_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_jobhistory
    ADD CONSTRAINT jobsub_jobhistory_pkey PRIMARY KEY (id);


--
-- Name: jobsub_oozieaction jobsub_oozieaction_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_oozieaction
    ADD CONSTRAINT jobsub_oozieaction_pkey PRIMARY KEY (id);


--
-- Name: jobsub_ooziedesign jobsub_ooziedesign_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_ooziedesign
    ADD CONSTRAINT jobsub_ooziedesign_pkey PRIMARY KEY (id);


--
-- Name: jobsub_ooziejavaaction jobsub_ooziejavaaction_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_ooziejavaaction
    ADD CONSTRAINT jobsub_ooziejavaaction_pkey PRIMARY KEY (oozieaction_ptr_id);


--
-- Name: jobsub_ooziemapreduceaction jobsub_ooziemapreduceaction_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_ooziemapreduceaction
    ADD CONSTRAINT jobsub_ooziemapreduceaction_pkey PRIMARY KEY (oozieaction_ptr_id);


--
-- Name: jobsub_ooziestreamingaction jobsub_ooziestreamingaction_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_ooziestreamingaction
    ADD CONSTRAINT jobsub_ooziestreamingaction_pkey PRIMARY KEY (oozieaction_ptr_id);


--
-- Name: oozie_bundle oozie_bundle_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_bundle
    ADD CONSTRAINT oozie_bundle_pkey PRIMARY KEY (job_ptr_id);


--
-- Name: oozie_bundledcoordinator oozie_bundledcoordinator_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_bundledcoordinator
    ADD CONSTRAINT oozie_bundledcoordinator_pkey PRIMARY KEY (id);


--
-- Name: oozie_coordinator oozie_coordinator_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_coordinator
    ADD CONSTRAINT oozie_coordinator_pkey PRIMARY KEY (job_ptr_id);


--
-- Name: oozie_datainput oozie_datainput_dataset_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_datainput
    ADD CONSTRAINT oozie_datainput_dataset_id_key UNIQUE (dataset_id);


--
-- Name: oozie_datainput oozie_datainput_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_datainput
    ADD CONSTRAINT oozie_datainput_pkey PRIMARY KEY (id);


--
-- Name: oozie_dataoutput oozie_dataoutput_dataset_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_dataoutput
    ADD CONSTRAINT oozie_dataoutput_dataset_id_key UNIQUE (dataset_id);


--
-- Name: oozie_dataoutput oozie_dataoutput_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_dataoutput
    ADD CONSTRAINT oozie_dataoutput_pkey PRIMARY KEY (id);


--
-- Name: oozie_dataset oozie_dataset_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_dataset
    ADD CONSTRAINT oozie_dataset_pkey PRIMARY KEY (id);


--
-- Name: oozie_decision oozie_decision_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_decision
    ADD CONSTRAINT oozie_decision_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_decisionend oozie_decisionend_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_decisionend
    ADD CONSTRAINT oozie_decisionend_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_distcp oozie_distcp_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_distcp
    ADD CONSTRAINT oozie_distcp_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_email oozie_email_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_email
    ADD CONSTRAINT oozie_email_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_end oozie_end_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_end
    ADD CONSTRAINT oozie_end_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_fork oozie_fork_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_fork
    ADD CONSTRAINT oozie_fork_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_fs oozie_fs_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_fs
    ADD CONSTRAINT oozie_fs_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_generic oozie_generic_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_generic
    ADD CONSTRAINT oozie_generic_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_history oozie_history_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_history
    ADD CONSTRAINT oozie_history_pkey PRIMARY KEY (id);


--
-- Name: oozie_hive oozie_hive_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_hive
    ADD CONSTRAINT oozie_hive_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_java oozie_java_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_java
    ADD CONSTRAINT oozie_java_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_job oozie_job_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_job
    ADD CONSTRAINT oozie_job_pkey PRIMARY KEY (id);


--
-- Name: oozie_join oozie_join_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_join
    ADD CONSTRAINT oozie_join_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_kill oozie_kill_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_kill
    ADD CONSTRAINT oozie_kill_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_link oozie_link_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_link
    ADD CONSTRAINT oozie_link_pkey PRIMARY KEY (id);


--
-- Name: oozie_mapreduce oozie_mapreduce_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_mapreduce
    ADD CONSTRAINT oozie_mapreduce_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_node oozie_node_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_node
    ADD CONSTRAINT oozie_node_pkey PRIMARY KEY (id);


--
-- Name: oozie_pig oozie_pig_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_pig
    ADD CONSTRAINT oozie_pig_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_shell oozie_shell_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_shell
    ADD CONSTRAINT oozie_shell_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_sqoop oozie_sqoop_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_sqoop
    ADD CONSTRAINT oozie_sqoop_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_ssh oozie_ssh_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_ssh
    ADD CONSTRAINT oozie_ssh_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_start oozie_start_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_start
    ADD CONSTRAINT oozie_start_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_streaming oozie_streaming_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_streaming
    ADD CONSTRAINT oozie_streaming_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_subworkflow oozie_subworkflow_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_subworkflow
    ADD CONSTRAINT oozie_subworkflow_pkey PRIMARY KEY (node_ptr_id);


--
-- Name: oozie_workflow oozie_workflow_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_workflow
    ADD CONSTRAINT oozie_workflow_pkey PRIMARY KEY (job_ptr_id);


--
-- Name: pig_document pig_document_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.pig_document
    ADD CONSTRAINT pig_document_pkey PRIMARY KEY (id);


--
-- Name: pig_pigscript pig_pigscript_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.pig_pigscript
    ADD CONSTRAINT pig_pigscript_pkey PRIMARY KEY (document_ptr_id);


--
-- Name: useradmin_grouppermission useradmin_grouppermission_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.useradmin_grouppermission
    ADD CONSTRAINT useradmin_grouppermission_pkey PRIMARY KEY (id);


--
-- Name: useradmin_huepermission useradmin_huepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.useradmin_huepermission
    ADD CONSTRAINT useradmin_huepermission_pkey PRIMARY KEY (id);


--
-- Name: useradmin_ldapgroup useradmin_ldapgroup_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.useradmin_ldapgroup
    ADD CONSTRAINT useradmin_ldapgroup_pkey PRIMARY KEY (id);


--
-- Name: useradmin_userprofile useradmin_userprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.useradmin_userprofile
    ADD CONSTRAINT useradmin_userprofile_pkey PRIMARY KEY (id);


--
-- Name: useradmin_userprofile useradmin_userprofile_user_id_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.useradmin_userprofile
    ADD CONSTRAINT useradmin_userprofile_user_id_key UNIQUE (user_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON public.authtoken_token USING btree (key varchar_pattern_ops);


--
-- Name: axes_accessattempt_ip_address_10922d9c; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX axes_accessattempt_ip_address_10922d9c ON public.axes_accessattempt USING btree (ip_address);


--
-- Name: axes_accessattempt_user_agent_ad89678b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX axes_accessattempt_user_agent_ad89678b ON public.axes_accessattempt USING btree (user_agent);


--
-- Name: axes_accessattempt_user_agent_ad89678b_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX axes_accessattempt_user_agent_ad89678b_like ON public.axes_accessattempt USING btree (user_agent varchar_pattern_ops);


--
-- Name: axes_accessattempt_username_3f2d4ca0; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX axes_accessattempt_username_3f2d4ca0 ON public.axes_accessattempt USING btree (username);


--
-- Name: axes_accessattempt_username_3f2d4ca0_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX axes_accessattempt_username_3f2d4ca0_like ON public.axes_accessattempt USING btree (username varchar_pattern_ops);


--
-- Name: axes_accesslog_ip_address_86b417e5; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX axes_accesslog_ip_address_86b417e5 ON public.axes_accesslog USING btree (ip_address);


--
-- Name: axes_accesslog_user_agent_0e659004; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX axes_accesslog_user_agent_0e659004 ON public.axes_accesslog USING btree (user_agent);


--
-- Name: axes_accesslog_user_agent_0e659004_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX axes_accesslog_user_agent_0e659004_like ON public.axes_accesslog USING btree (user_agent varchar_pattern_ops);


--
-- Name: axes_accesslog_username_df93064b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX axes_accesslog_username_df93064b ON public.axes_accesslog USING btree (username);


--
-- Name: axes_accesslog_username_df93064b_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX axes_accesslog_username_df93064b_like ON public.axes_accesslog USING btree (username varchar_pattern_ops);


--
-- Name: beeswax_queryhistory_design_id_8b19f1ba; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX beeswax_queryhistory_design_id_8b19f1ba ON public.beeswax_queryhistory USING btree (design_id);


--
-- Name: beeswax_queryhistory_last_state_3b123643; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX beeswax_queryhistory_last_state_3b123643 ON public.beeswax_queryhistory USING btree (last_state);


--
-- Name: beeswax_queryhistory_owner_id_f56d0c52; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX beeswax_queryhistory_owner_id_f56d0c52 ON public.beeswax_queryhistory USING btree (owner_id);


--
-- Name: beeswax_savedquery_is_auto_7ba521ab; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX beeswax_savedquery_is_auto_7ba521ab ON public.beeswax_savedquery USING btree (is_auto);


--
-- Name: beeswax_savedquery_is_trashed_8dc60321; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX beeswax_savedquery_is_trashed_8dc60321 ON public.beeswax_savedquery USING btree (is_trashed);


--
-- Name: beeswax_savedquery_owner_id_f98eb824; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX beeswax_savedquery_owner_id_f98eb824 ON public.beeswax_savedquery USING btree (owner_id);


--
-- Name: beeswax_session_last_used_df0f793b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX beeswax_session_last_used_df0f793b ON public.beeswax_session USING btree (last_used);


--
-- Name: beeswax_session_owner_id_46797e50; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX beeswax_session_owner_id_46797e50 ON public.beeswax_session USING btree (owner_id);


--
-- Name: defaultconfiguration_groups_defaultconfiguration_id_16cbc944; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX defaultconfiguration_groups_defaultconfiguration_id_16cbc944 ON public.defaultconfiguration_groups USING btree (defaultconfiguration_id);


--
-- Name: defaultconfiguration_groups_group_id_f9733e62; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX defaultconfiguration_groups_group_id_f9733e62 ON public.defaultconfiguration_groups USING btree (group_id);


--
-- Name: desktop_connector_dialect_0d1539ca; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_connector_dialect_0d1539ca ON public.desktop_connector USING btree (dialect);


--
-- Name: desktop_connector_dialect_0d1539ca_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_connector_dialect_0d1539ca_like ON public.desktop_connector USING btree (dialect varchar_pattern_ops);


--
-- Name: desktop_connector_interface_2a9a31a6; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_connector_interface_2a9a31a6 ON public.desktop_connector USING btree (interface);


--
-- Name: desktop_connector_interface_2a9a31a6_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_connector_interface_2a9a31a6_like ON public.desktop_connector USING btree (interface varchar_pattern_ops);


--
-- Name: desktop_connector_last_modified_954fecde; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_connector_last_modified_954fecde ON public.desktop_connector USING btree (last_modified);


--
-- Name: desktop_defaultconfiguration_app_2a22dcdc; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_defaultconfiguration_app_2a22dcdc ON public.desktop_defaultconfiguration USING btree (app);


--
-- Name: desktop_defaultconfiguration_app_2a22dcdc_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_defaultconfiguration_app_2a22dcdc_like ON public.desktop_defaultconfiguration USING btree (app varchar_pattern_ops);


--
-- Name: desktop_defaultconfiguration_is_default_3a224335; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_defaultconfiguration_is_default_3a224335 ON public.desktop_defaultconfiguration USING btree (is_default);


--
-- Name: desktop_defaultconfiguration_user_id_8611da32; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_defaultconfiguration_user_id_8611da32 ON public.desktop_defaultconfiguration USING btree (user_id);


--
-- Name: desktop_document2_connector_id_62b342cf; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document2_connector_id_62b342cf ON public.desktop_document2 USING btree (connector_id);


--
-- Name: desktop_document2_dependencies_from_document2_id_e5f62f5a; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document2_dependencies_from_document2_id_e5f62f5a ON public.desktop_document2_dependencies USING btree (from_document2_id);


--
-- Name: desktop_document2_dependencies_to_document2_id_2a18afeb; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document2_dependencies_to_document2_id_2a18afeb ON public.desktop_document2_dependencies USING btree (to_document2_id);


--
-- Name: desktop_document2_is_history_c15f5853; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document2_is_history_c15f5853 ON public.desktop_document2 USING btree (is_history);


--
-- Name: desktop_document2_is_managed_572d9c22; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document2_is_managed_572d9c22 ON public.desktop_document2 USING btree (is_managed);


--
-- Name: desktop_document2_is_trashed_e36a0b8a; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document2_is_trashed_e36a0b8a ON public.desktop_document2 USING btree (is_trashed);


--
-- Name: desktop_document2_last_modified_15243c0d; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document2_last_modified_15243c0d ON public.desktop_document2 USING btree (last_modified);


--
-- Name: desktop_document2_owner_id_342662fe; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document2_owner_id_342662fe ON public.desktop_document2 USING btree (owner_id);


--
-- Name: desktop_document2_parent_directory_id_428ead9c; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document2_parent_directory_id_428ead9c ON public.desktop_document2 USING btree (parent_directory_id);


--
-- Name: desktop_document2_type_7a9e90a7; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document2_type_7a9e90a7 ON public.desktop_document2 USING btree (type);


--
-- Name: desktop_document2_type_7a9e90a7_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document2_type_7a9e90a7_like ON public.desktop_document2 USING btree (type varchar_pattern_ops);


--
-- Name: desktop_document2_uuid_01e04a24; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document2_uuid_01e04a24 ON public.desktop_document2 USING btree (uuid);


--
-- Name: desktop_document2_uuid_01e04a24_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document2_uuid_01e04a24_like ON public.desktop_document2 USING btree (uuid varchar_pattern_ops);


--
-- Name: desktop_document2_version_2299c6bb; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document2_version_2299c6bb ON public.desktop_document2 USING btree (version);


--
-- Name: desktop_document2permission_doc_id_b851e790; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document2permission_doc_id_b851e790 ON public.desktop_document2permission USING btree (doc_id);


--
-- Name: desktop_document2permission_perms_449c1144; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document2permission_perms_449c1144 ON public.desktop_document2permission USING btree (perms);


--
-- Name: desktop_document2permission_perms_449c1144_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document2permission_perms_449c1144_like ON public.desktop_document2permission USING btree (perms varchar_pattern_ops);


--
-- Name: desktop_document_content_type_id_fe7f05ef; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document_content_type_id_fe7f05ef ON public.desktop_document USING btree (content_type_id);


--
-- Name: desktop_document_last_modified_36ad4264; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document_last_modified_36ad4264 ON public.desktop_document USING btree (last_modified);


--
-- Name: desktop_document_owner_id_6209716b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document_owner_id_6209716b ON public.desktop_document USING btree (owner_id);


--
-- Name: desktop_document_tags_document_id_97885747; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document_tags_document_id_97885747 ON public.desktop_document_tags USING btree (document_id);


--
-- Name: desktop_document_tags_documenttag_id_4ac450c6; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_document_tags_documenttag_id_4ac450c6 ON public.desktop_document_tags USING btree (documenttag_id);


--
-- Name: desktop_documentpermission_doc_id_f3913804; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_documentpermission_doc_id_f3913804 ON public.desktop_documentpermission USING btree (doc_id);


--
-- Name: desktop_documenttag_owner_id_74dfe3a5; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_documenttag_owner_id_74dfe3a5 ON public.desktop_documenttag USING btree (owner_id);


--
-- Name: desktop_documenttag_tag_0cc3fdde; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_documenttag_tag_0cc3fdde ON public.desktop_documenttag USING btree (tag);


--
-- Name: desktop_documenttag_tag_0cc3fdde_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_documenttag_tag_0cc3fdde_like ON public.desktop_documenttag USING btree (tag varchar_pattern_ops);


--
-- Name: desktop_settings_collect_usage_a62e7068; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_settings_collect_usage_a62e7068 ON public.desktop_settings USING btree (collect_usage);


--
-- Name: desktop_settings_tours_and_tutorials_376b46bd; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_settings_tours_and_tutorials_376b46bd ON public.desktop_settings USING btree (tours_and_tutorials);


--
-- Name: desktop_userpreferences_user_id_f372df8e; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX desktop_userpreferences_user_id_f372df8e ON public.desktop_userpreferences USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: documentpermission2_groups_document2permission_id_1f9f783b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX documentpermission2_groups_document2permission_id_1f9f783b ON public.documentpermission2_groups USING btree (document2permission_id);


--
-- Name: documentpermission2_groups_group_id_7efb8a45; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX documentpermission2_groups_group_id_7efb8a45 ON public.documentpermission2_groups USING btree (group_id);


--
-- Name: documentpermission2_users_document2permission_id_ad7af084; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX documentpermission2_users_document2permission_id_ad7af084 ON public.documentpermission2_users USING btree (document2permission_id);


--
-- Name: documentpermission2_users_user_id_848e20ce; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX documentpermission2_users_user_id_848e20ce ON public.documentpermission2_users USING btree (user_id);


--
-- Name: documentpermission_groups_documentpermission_id_d838bd22; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX documentpermission_groups_documentpermission_id_d838bd22 ON public.documentpermission_groups USING btree (documentpermission_id);


--
-- Name: documentpermission_groups_group_id_d44a4071; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX documentpermission_groups_group_id_d44a4071 ON public.documentpermission_groups USING btree (group_id);


--
-- Name: documentpermission_users_documentpermission_id_4546e93f; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX documentpermission_users_documentpermission_id_4546e93f ON public.documentpermission_users USING btree (documentpermission_id);


--
-- Name: documentpermission_users_user_id_4afc7785; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX documentpermission_users_user_id_4afc7785 ON public.documentpermission_users USING btree (user_id);


--
-- Name: jobsub_jobdesign_owner_id_648998a1; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX jobsub_jobdesign_owner_id_648998a1 ON public.jobsub_jobdesign USING btree (owner_id);


--
-- Name: jobsub_jobhistory_design_id_06d16a98; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX jobsub_jobhistory_design_id_06d16a98 ON public.jobsub_jobhistory USING btree (design_id);


--
-- Name: jobsub_jobhistory_owner_id_5bdaa10b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX jobsub_jobhistory_owner_id_5bdaa10b ON public.jobsub_jobhistory USING btree (owner_id);


--
-- Name: jobsub_ooziedesign_owner_id_cb5405f3; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX jobsub_ooziedesign_owner_id_cb5405f3 ON public.jobsub_ooziedesign USING btree (owner_id);


--
-- Name: jobsub_ooziedesign_root_action_id_a68cdf79; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX jobsub_ooziedesign_root_action_id_a68cdf79 ON public.jobsub_ooziedesign USING btree (root_action_id);


--
-- Name: oozie_bundledcoordinator_bundle_id_c0a51e15; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX oozie_bundledcoordinator_bundle_id_c0a51e15 ON public.oozie_bundledcoordinator USING btree (bundle_id);


--
-- Name: oozie_bundledcoordinator_coordinator_id_deb5052a; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX oozie_bundledcoordinator_coordinator_id_deb5052a ON public.oozie_bundledcoordinator USING btree (coordinator_id);


--
-- Name: oozie_coordinator_coordinatorworkflow_id_b6161414; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX oozie_coordinator_coordinatorworkflow_id_b6161414 ON public.oozie_coordinator USING btree (coordinatorworkflow_id);


--
-- Name: oozie_datainput_coordinator_id_d8d911b9; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX oozie_datainput_coordinator_id_d8d911b9 ON public.oozie_datainput USING btree (coordinator_id);


--
-- Name: oozie_dataoutput_coordinator_id_12e73c29; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX oozie_dataoutput_coordinator_id_12e73c29 ON public.oozie_dataoutput USING btree (coordinator_id);


--
-- Name: oozie_dataset_coordinator_id_4d1eb286; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX oozie_dataset_coordinator_id_4d1eb286 ON public.oozie_dataset USING btree (coordinator_id);


--
-- Name: oozie_history_job_id_fbea900b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX oozie_history_job_id_fbea900b ON public.oozie_history USING btree (job_id);


--
-- Name: oozie_history_submission_date_85ff5210; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX oozie_history_submission_date_85ff5210 ON public.oozie_history USING btree (submission_date);


--
-- Name: oozie_history_submitter_id_b55e2183; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX oozie_history_submitter_id_b55e2183 ON public.oozie_history USING btree (submitter_id);


--
-- Name: oozie_job_is_shared_353b5458; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX oozie_job_is_shared_353b5458 ON public.oozie_job USING btree (is_shared);


--
-- Name: oozie_job_is_trashed_da42d7e5; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX oozie_job_is_trashed_da42d7e5 ON public.oozie_job USING btree (is_trashed);


--
-- Name: oozie_job_last_modified_75350e87; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX oozie_job_last_modified_75350e87 ON public.oozie_job USING btree (last_modified);


--
-- Name: oozie_job_owner_id_c255618e; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX oozie_job_owner_id_c255618e ON public.oozie_job USING btree (owner_id);


--
-- Name: oozie_link_child_id_c3e8341e; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX oozie_link_child_id_c3e8341e ON public.oozie_link USING btree (child_id);


--
-- Name: oozie_link_parent_id_5b2a2286; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX oozie_link_parent_id_5b2a2286 ON public.oozie_link USING btree (parent_id);


--
-- Name: oozie_node_workflow_id_a6bd1a69; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX oozie_node_workflow_id_a6bd1a69 ON public.oozie_node USING btree (workflow_id);


--
-- Name: oozie_subworkflow_sub_workflow_id_4e2908b9; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX oozie_subworkflow_sub_workflow_id_4e2908b9 ON public.oozie_subworkflow USING btree (sub_workflow_id);


--
-- Name: oozie_workflow_end_id_2f6d0f36; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX oozie_workflow_end_id_2f6d0f36 ON public.oozie_workflow USING btree (end_id);


--
-- Name: oozie_workflow_start_id_677c5e08; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX oozie_workflow_start_id_677c5e08 ON public.oozie_workflow USING btree (start_id);


--
-- Name: pig_document_is_design_f1e0139b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX pig_document_is_design_f1e0139b ON public.pig_document USING btree (is_design);


--
-- Name: pig_document_owner_id_27d3660e; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX pig_document_owner_id_27d3660e ON public.pig_document USING btree (owner_id);


--
-- Name: useradmin_grouppermission_group_id_da9c1a34; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX useradmin_grouppermission_group_id_da9c1a34 ON public.useradmin_grouppermission USING btree (group_id);


--
-- Name: useradmin_grouppermission_hue_permission_id_ece6426f; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX useradmin_grouppermission_hue_permission_id_ece6426f ON public.useradmin_grouppermission USING btree (hue_permission_id);


--
-- Name: useradmin_ldapgroup_group_id_162e4d49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX useradmin_ldapgroup_group_id_162e4d49 ON public.useradmin_ldapgroup USING btree (group_id);


--
-- Name: useradmin_userprofile_last_activity_c0e0b56b; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX useradmin_userprofile_last_activity_c0e0b56b ON public.useradmin_userprofile USING btree (last_activity);


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authtoken_token authtoken_token_user_id_35299eff_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: beeswax_queryhistory beeswax_queryhistory_design_id_8b19f1ba_fk_beeswax_s; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.beeswax_queryhistory
    ADD CONSTRAINT beeswax_queryhistory_design_id_8b19f1ba_fk_beeswax_s FOREIGN KEY (design_id) REFERENCES public.beeswax_savedquery(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: beeswax_queryhistory beeswax_queryhistory_owner_id_f56d0c52_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.beeswax_queryhistory
    ADD CONSTRAINT beeswax_queryhistory_owner_id_f56d0c52_fk_auth_user_id FOREIGN KEY (owner_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: beeswax_savedquery beeswax_savedquery_owner_id_f98eb824_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.beeswax_savedquery
    ADD CONSTRAINT beeswax_savedquery_owner_id_f98eb824_fk_auth_user_id FOREIGN KEY (owner_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: beeswax_session beeswax_session_owner_id_46797e50_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.beeswax_session
    ADD CONSTRAINT beeswax_session_owner_id_46797e50_fk_auth_user_id FOREIGN KEY (owner_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: defaultconfiguration_groups defaultconfiguration_defaultconfiguration_16cbc944_fk_desktop_d; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.defaultconfiguration_groups
    ADD CONSTRAINT defaultconfiguration_defaultconfiguration_16cbc944_fk_desktop_d FOREIGN KEY (defaultconfiguration_id) REFERENCES public.desktop_defaultconfiguration(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: defaultconfiguration_groups defaultconfiguration_groups_group_id_f9733e62_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.defaultconfiguration_groups
    ADD CONSTRAINT defaultconfiguration_groups_group_id_f9733e62_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: desktop_defaultconfiguration desktop_defaultconfiguration_user_id_8611da32_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_defaultconfiguration
    ADD CONSTRAINT desktop_defaultconfiguration_user_id_8611da32_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: desktop_document2 desktop_document2_connector_id_62b342cf_fk_desktop_connector_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document2
    ADD CONSTRAINT desktop_document2_connector_id_62b342cf_fk_desktop_connector_id FOREIGN KEY (connector_id) REFERENCES public.desktop_connector(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: desktop_document2_dependencies desktop_document2_de_from_document2_id_e5f62f5a_fk_desktop_d; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document2_dependencies
    ADD CONSTRAINT desktop_document2_de_from_document2_id_e5f62f5a_fk_desktop_d FOREIGN KEY (from_document2_id) REFERENCES public.desktop_document2(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: desktop_document2_dependencies desktop_document2_de_to_document2_id_2a18afeb_fk_desktop_d; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document2_dependencies
    ADD CONSTRAINT desktop_document2_de_to_document2_id_2a18afeb_fk_desktop_d FOREIGN KEY (to_document2_id) REFERENCES public.desktop_document2(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: desktop_document2 desktop_document2_owner_id_342662fe_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document2
    ADD CONSTRAINT desktop_document2_owner_id_342662fe_fk_auth_user_id FOREIGN KEY (owner_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: desktop_document2 desktop_document2_parent_directory_id_428ead9c_fk_desktop_d; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document2
    ADD CONSTRAINT desktop_document2_parent_directory_id_428ead9c_fk_desktop_d FOREIGN KEY (parent_directory_id) REFERENCES public.desktop_document2(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: desktop_document2permission desktop_document2per_doc_id_b851e790_fk_desktop_d; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document2permission
    ADD CONSTRAINT desktop_document2per_doc_id_b851e790_fk_desktop_d FOREIGN KEY (doc_id) REFERENCES public.desktop_document2(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: desktop_document desktop_document_content_type_id_fe7f05ef_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document
    ADD CONSTRAINT desktop_document_content_type_id_fe7f05ef_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: desktop_document desktop_document_owner_id_6209716b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document
    ADD CONSTRAINT desktop_document_owner_id_6209716b_fk_auth_user_id FOREIGN KEY (owner_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: desktop_document_tags desktop_document_tag_document_id_97885747_fk_desktop_d; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document_tags
    ADD CONSTRAINT desktop_document_tag_document_id_97885747_fk_desktop_d FOREIGN KEY (document_id) REFERENCES public.desktop_document(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: desktop_document_tags desktop_document_tag_documenttag_id_4ac450c6_fk_desktop_d; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_document_tags
    ADD CONSTRAINT desktop_document_tag_documenttag_id_4ac450c6_fk_desktop_d FOREIGN KEY (documenttag_id) REFERENCES public.desktop_documenttag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: desktop_documentpermission desktop_documentperm_doc_id_f3913804_fk_desktop_d; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_documentpermission
    ADD CONSTRAINT desktop_documentperm_doc_id_f3913804_fk_desktop_d FOREIGN KEY (doc_id) REFERENCES public.desktop_document(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: desktop_documenttag desktop_documenttag_owner_id_74dfe3a5_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_documenttag
    ADD CONSTRAINT desktop_documenttag_owner_id_74dfe3a5_fk_auth_user_id FOREIGN KEY (owner_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: desktop_userpreferences desktop_userpreferences_user_id_f372df8e_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.desktop_userpreferences
    ADD CONSTRAINT desktop_userpreferences_user_id_f372df8e_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: documentpermission2_groups documentpermission2__document2permission__1f9f783b_fk_desktop_d; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission2_groups
    ADD CONSTRAINT documentpermission2__document2permission__1f9f783b_fk_desktop_d FOREIGN KEY (document2permission_id) REFERENCES public.desktop_document2permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: documentpermission2_users documentpermission2__document2permission__ad7af084_fk_desktop_d; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission2_users
    ADD CONSTRAINT documentpermission2__document2permission__ad7af084_fk_desktop_d FOREIGN KEY (document2permission_id) REFERENCES public.desktop_document2permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: documentpermission2_groups documentpermission2_groups_group_id_7efb8a45_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission2_groups
    ADD CONSTRAINT documentpermission2_groups_group_id_7efb8a45_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: documentpermission2_users documentpermission2_users_user_id_848e20ce_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission2_users
    ADD CONSTRAINT documentpermission2_users_user_id_848e20ce_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: documentpermission_groups documentpermission_g_documentpermission_i_d838bd22_fk_desktop_d; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission_groups
    ADD CONSTRAINT documentpermission_g_documentpermission_i_d838bd22_fk_desktop_d FOREIGN KEY (documentpermission_id) REFERENCES public.desktop_documentpermission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: documentpermission_groups documentpermission_groups_group_id_d44a4071_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission_groups
    ADD CONSTRAINT documentpermission_groups_group_id_d44a4071_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: documentpermission_users documentpermission_u_documentpermission_i_4546e93f_fk_desktop_d; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission_users
    ADD CONSTRAINT documentpermission_u_documentpermission_i_4546e93f_fk_desktop_d FOREIGN KEY (documentpermission_id) REFERENCES public.desktop_documentpermission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: documentpermission_users documentpermission_users_user_id_4afc7785_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.documentpermission_users
    ADD CONSTRAINT documentpermission_users_user_id_4afc7785_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: jobsub_jobdesign jobsub_jobdesign_owner_id_648998a1_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_jobdesign
    ADD CONSTRAINT jobsub_jobdesign_owner_id_648998a1_fk_auth_user_id FOREIGN KEY (owner_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: jobsub_jobhistory jobsub_jobhistory_design_id_06d16a98_fk_jobsub_ooziedesign_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_jobhistory
    ADD CONSTRAINT jobsub_jobhistory_design_id_06d16a98_fk_jobsub_ooziedesign_id FOREIGN KEY (design_id) REFERENCES public.jobsub_ooziedesign(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: jobsub_jobhistory jobsub_jobhistory_owner_id_5bdaa10b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_jobhistory
    ADD CONSTRAINT jobsub_jobhistory_owner_id_5bdaa10b_fk_auth_user_id FOREIGN KEY (owner_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: jobsub_ooziedesign jobsub_ooziedesign_owner_id_cb5405f3_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_ooziedesign
    ADD CONSTRAINT jobsub_ooziedesign_owner_id_cb5405f3_fk_auth_user_id FOREIGN KEY (owner_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: jobsub_ooziedesign jobsub_ooziedesign_root_action_id_a68cdf79_fk_jobsub_oo; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_ooziedesign
    ADD CONSTRAINT jobsub_ooziedesign_root_action_id_a68cdf79_fk_jobsub_oo FOREIGN KEY (root_action_id) REFERENCES public.jobsub_oozieaction(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: jobsub_ooziejavaaction jobsub_ooziejavaacti_oozieaction_ptr_id_0f52fef4_fk_jobsub_oo; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_ooziejavaaction
    ADD CONSTRAINT jobsub_ooziejavaacti_oozieaction_ptr_id_0f52fef4_fk_jobsub_oo FOREIGN KEY (oozieaction_ptr_id) REFERENCES public.jobsub_oozieaction(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: jobsub_ooziemapreduceaction jobsub_ooziemapreduc_oozieaction_ptr_id_92fe5d48_fk_jobsub_oo; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_ooziemapreduceaction
    ADD CONSTRAINT jobsub_ooziemapreduc_oozieaction_ptr_id_92fe5d48_fk_jobsub_oo FOREIGN KEY (oozieaction_ptr_id) REFERENCES public.jobsub_oozieaction(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: jobsub_ooziestreamingaction jobsub_ooziestreamin_oozieaction_ptr_id_8007acc7_fk_jobsub_oo; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.jobsub_ooziestreamingaction
    ADD CONSTRAINT jobsub_ooziestreamin_oozieaction_ptr_id_8007acc7_fk_jobsub_oo FOREIGN KEY (oozieaction_ptr_id) REFERENCES public.jobsub_oozieaction(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_bundle oozie_bundle_job_ptr_id_0c53aa88_fk_oozie_job_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_bundle
    ADD CONSTRAINT oozie_bundle_job_ptr_id_0c53aa88_fk_oozie_job_id FOREIGN KEY (job_ptr_id) REFERENCES public.oozie_job(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_bundledcoordinator oozie_bundledcoordin_bundle_id_c0a51e15_fk_oozie_bun; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_bundledcoordinator
    ADD CONSTRAINT oozie_bundledcoordin_bundle_id_c0a51e15_fk_oozie_bun FOREIGN KEY (bundle_id) REFERENCES public.oozie_bundle(job_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_bundledcoordinator oozie_bundledcoordin_coordinator_id_deb5052a_fk_oozie_coo; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_bundledcoordinator
    ADD CONSTRAINT oozie_bundledcoordin_coordinator_id_deb5052a_fk_oozie_coo FOREIGN KEY (coordinator_id) REFERENCES public.oozie_coordinator(job_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_coordinator oozie_coordinator_coordinatorworkflow__b6161414_fk_oozie_wor; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_coordinator
    ADD CONSTRAINT oozie_coordinator_coordinatorworkflow__b6161414_fk_oozie_wor FOREIGN KEY (coordinatorworkflow_id) REFERENCES public.oozie_workflow(job_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_coordinator oozie_coordinator_job_ptr_id_59cbcc0c_fk_oozie_job_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_coordinator
    ADD CONSTRAINT oozie_coordinator_job_ptr_id_59cbcc0c_fk_oozie_job_id FOREIGN KEY (job_ptr_id) REFERENCES public.oozie_job(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_datainput oozie_datainput_coordinator_id_d8d911b9_fk_oozie_coo; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_datainput
    ADD CONSTRAINT oozie_datainput_coordinator_id_d8d911b9_fk_oozie_coo FOREIGN KEY (coordinator_id) REFERENCES public.oozie_coordinator(job_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_datainput oozie_datainput_dataset_id_5fcb31a7_fk_oozie_dataset_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_datainput
    ADD CONSTRAINT oozie_datainput_dataset_id_5fcb31a7_fk_oozie_dataset_id FOREIGN KEY (dataset_id) REFERENCES public.oozie_dataset(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_dataoutput oozie_dataoutput_coordinator_id_12e73c29_fk_oozie_coo; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_dataoutput
    ADD CONSTRAINT oozie_dataoutput_coordinator_id_12e73c29_fk_oozie_coo FOREIGN KEY (coordinator_id) REFERENCES public.oozie_coordinator(job_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_dataoutput oozie_dataoutput_dataset_id_84e68919_fk_oozie_dataset_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_dataoutput
    ADD CONSTRAINT oozie_dataoutput_dataset_id_84e68919_fk_oozie_dataset_id FOREIGN KEY (dataset_id) REFERENCES public.oozie_dataset(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_dataset oozie_dataset_coordinator_id_4d1eb286_fk_oozie_coo; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_dataset
    ADD CONSTRAINT oozie_dataset_coordinator_id_4d1eb286_fk_oozie_coo FOREIGN KEY (coordinator_id) REFERENCES public.oozie_coordinator(job_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_decision oozie_decision_node_ptr_id_1ee18de2_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_decision
    ADD CONSTRAINT oozie_decision_node_ptr_id_1ee18de2_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_decisionend oozie_decisionend_node_ptr_id_ec0ad089_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_decisionend
    ADD CONSTRAINT oozie_decisionend_node_ptr_id_ec0ad089_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_distcp oozie_distcp_node_ptr_id_0f63bff7_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_distcp
    ADD CONSTRAINT oozie_distcp_node_ptr_id_0f63bff7_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_email oozie_email_node_ptr_id_b6164766_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_email
    ADD CONSTRAINT oozie_email_node_ptr_id_b6164766_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_end oozie_end_node_ptr_id_9a6db5e6_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_end
    ADD CONSTRAINT oozie_end_node_ptr_id_9a6db5e6_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_fork oozie_fork_node_ptr_id_286409b0_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_fork
    ADD CONSTRAINT oozie_fork_node_ptr_id_286409b0_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_fs oozie_fs_node_ptr_id_324d62ec_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_fs
    ADD CONSTRAINT oozie_fs_node_ptr_id_324d62ec_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_generic oozie_generic_node_ptr_id_39a1a65a_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_generic
    ADD CONSTRAINT oozie_generic_node_ptr_id_39a1a65a_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_history oozie_history_job_id_fbea900b_fk_oozie_job_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_history
    ADD CONSTRAINT oozie_history_job_id_fbea900b_fk_oozie_job_id FOREIGN KEY (job_id) REFERENCES public.oozie_job(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_history oozie_history_submitter_id_b55e2183_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_history
    ADD CONSTRAINT oozie_history_submitter_id_b55e2183_fk_auth_user_id FOREIGN KEY (submitter_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_hive oozie_hive_node_ptr_id_747c09c7_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_hive
    ADD CONSTRAINT oozie_hive_node_ptr_id_747c09c7_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_java oozie_java_node_ptr_id_41ceeff8_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_java
    ADD CONSTRAINT oozie_java_node_ptr_id_41ceeff8_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_job oozie_job_owner_id_c255618e_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_job
    ADD CONSTRAINT oozie_job_owner_id_c255618e_fk_auth_user_id FOREIGN KEY (owner_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_join oozie_join_node_ptr_id_17901551_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_join
    ADD CONSTRAINT oozie_join_node_ptr_id_17901551_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_kill oozie_kill_node_ptr_id_6e3b4c7f_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_kill
    ADD CONSTRAINT oozie_kill_node_ptr_id_6e3b4c7f_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_link oozie_link_child_id_c3e8341e_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_link
    ADD CONSTRAINT oozie_link_child_id_c3e8341e_fk_oozie_node_id FOREIGN KEY (child_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_link oozie_link_parent_id_5b2a2286_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_link
    ADD CONSTRAINT oozie_link_parent_id_5b2a2286_fk_oozie_node_id FOREIGN KEY (parent_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_mapreduce oozie_mapreduce_node_ptr_id_5ef2cd6d_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_mapreduce
    ADD CONSTRAINT oozie_mapreduce_node_ptr_id_5ef2cd6d_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_node oozie_node_workflow_id_a6bd1a69_fk_oozie_workflow_job_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_node
    ADD CONSTRAINT oozie_node_workflow_id_a6bd1a69_fk_oozie_workflow_job_ptr_id FOREIGN KEY (workflow_id) REFERENCES public.oozie_workflow(job_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_pig oozie_pig_node_ptr_id_251c17e0_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_pig
    ADD CONSTRAINT oozie_pig_node_ptr_id_251c17e0_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_shell oozie_shell_node_ptr_id_4b2d0551_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_shell
    ADD CONSTRAINT oozie_shell_node_ptr_id_4b2d0551_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_sqoop oozie_sqoop_node_ptr_id_bc17434d_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_sqoop
    ADD CONSTRAINT oozie_sqoop_node_ptr_id_bc17434d_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_ssh oozie_ssh_node_ptr_id_f8399593_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_ssh
    ADD CONSTRAINT oozie_ssh_node_ptr_id_f8399593_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_start oozie_start_node_ptr_id_845ed7e5_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_start
    ADD CONSTRAINT oozie_start_node_ptr_id_845ed7e5_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_streaming oozie_streaming_node_ptr_id_33986c0c_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_streaming
    ADD CONSTRAINT oozie_streaming_node_ptr_id_33986c0c_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_subworkflow oozie_subworkflow_node_ptr_id_6d9b076e_fk_oozie_node_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_subworkflow
    ADD CONSTRAINT oozie_subworkflow_node_ptr_id_6d9b076e_fk_oozie_node_id FOREIGN KEY (node_ptr_id) REFERENCES public.oozie_node(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_subworkflow oozie_subworkflow_sub_workflow_id_4e2908b9_fk_oozie_wor; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_subworkflow
    ADD CONSTRAINT oozie_subworkflow_sub_workflow_id_4e2908b9_fk_oozie_wor FOREIGN KEY (sub_workflow_id) REFERENCES public.oozie_workflow(job_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_workflow oozie_workflow_end_id_2f6d0f36_fk_oozie_end_node_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_workflow
    ADD CONSTRAINT oozie_workflow_end_id_2f6d0f36_fk_oozie_end_node_ptr_id FOREIGN KEY (end_id) REFERENCES public.oozie_end(node_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_workflow oozie_workflow_job_ptr_id_8f44b9da_fk_oozie_job_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_workflow
    ADD CONSTRAINT oozie_workflow_job_ptr_id_8f44b9da_fk_oozie_job_id FOREIGN KEY (job_ptr_id) REFERENCES public.oozie_job(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: oozie_workflow oozie_workflow_start_id_677c5e08_fk_oozie_start_node_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.oozie_workflow
    ADD CONSTRAINT oozie_workflow_start_id_677c5e08_fk_oozie_start_node_ptr_id FOREIGN KEY (start_id) REFERENCES public.oozie_start(node_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: pig_document pig_document_owner_id_27d3660e_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.pig_document
    ADD CONSTRAINT pig_document_owner_id_27d3660e_fk_auth_user_id FOREIGN KEY (owner_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: pig_pigscript pig_pigscript_document_ptr_id_8cbae244_fk_pig_document_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.pig_pigscript
    ADD CONSTRAINT pig_pigscript_document_ptr_id_8cbae244_fk_pig_document_id FOREIGN KEY (document_ptr_id) REFERENCES public.pig_document(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: useradmin_grouppermission useradmin_grouppermi_hue_permission_id_ece6426f_fk_useradmin; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.useradmin_grouppermission
    ADD CONSTRAINT useradmin_grouppermi_hue_permission_id_ece6426f_fk_useradmin FOREIGN KEY (hue_permission_id) REFERENCES public.useradmin_huepermission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: useradmin_grouppermission useradmin_grouppermission_group_id_da9c1a34_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.useradmin_grouppermission
    ADD CONSTRAINT useradmin_grouppermission_group_id_da9c1a34_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: useradmin_ldapgroup useradmin_ldapgroup_group_id_162e4d49_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.useradmin_ldapgroup
    ADD CONSTRAINT useradmin_ldapgroup_group_id_162e4d49_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: useradmin_userprofile useradmin_userprofile_user_id_6333d17b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.useradmin_userprofile
    ADD CONSTRAINT useradmin_userprofile_user_id_6333d17b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: admin
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

