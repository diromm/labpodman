--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.9 (Debian 13.9-1.pgdg110+1)
-- Dumped by pg_dump version 15.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE metastore_db;
--
-- Name: metastore_db; Type: DATABASE; Schema: -; Owner: admin
--

CREATE DATABASE metastore_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE metastore_db OWNER TO admin;

\connect metastore_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: admin
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO admin;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: admin
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: AUX_TABLE; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."AUX_TABLE" (
    "MT_KEY1" character varying(128) NOT NULL,
    "MT_KEY2" bigint NOT NULL,
    "MT_COMMENT" character varying(255)
);


ALTER TABLE public."AUX_TABLE" OWNER TO admin;

--
-- Name: BUCKETING_COLS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."BUCKETING_COLS" (
    "SD_ID" bigint NOT NULL,
    "BUCKET_COL_NAME" character varying(256) DEFAULT NULL::character varying,
    "INTEGER_IDX" bigint NOT NULL
);


ALTER TABLE public."BUCKETING_COLS" OWNER TO admin;

--
-- Name: CDS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."CDS" (
    "CD_ID" bigint NOT NULL
);


ALTER TABLE public."CDS" OWNER TO admin;

--
-- Name: COLUMNS_V2; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."COLUMNS_V2" (
    "CD_ID" bigint NOT NULL,
    "COMMENT" character varying(4000),
    "COLUMN_NAME" character varying(767) NOT NULL,
    "TYPE_NAME" text,
    "INTEGER_IDX" integer NOT NULL
);


ALTER TABLE public."COLUMNS_V2" OWNER TO admin;

--
-- Name: COMPACTION_METRICS_CACHE; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."COMPACTION_METRICS_CACHE" (
    "CMC_DATABASE" character varying(128) NOT NULL,
    "CMC_TABLE" character varying(256) NOT NULL,
    "CMC_PARTITION" character varying(767),
    "CMC_METRIC_TYPE" character varying(128) NOT NULL,
    "CMC_METRIC_VALUE" integer NOT NULL,
    "CMC_VERSION" integer NOT NULL
);


ALTER TABLE public."COMPACTION_METRICS_CACHE" OWNER TO admin;

--
-- Name: COMPACTION_QUEUE; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."COMPACTION_QUEUE" (
    "CQ_ID" bigint NOT NULL,
    "CQ_DATABASE" character varying(128) NOT NULL,
    "CQ_TABLE" character varying(256) NOT NULL,
    "CQ_PARTITION" character varying(767),
    "CQ_STATE" character(1) NOT NULL,
    "CQ_TYPE" character(1) NOT NULL,
    "CQ_TBLPROPERTIES" character varying(2048),
    "CQ_WORKER_ID" character varying(128),
    "CQ_ENQUEUE_TIME" bigint,
    "CQ_START" bigint,
    "CQ_RUN_AS" character varying(128),
    "CQ_HIGHEST_WRITE_ID" bigint,
    "CQ_META_INFO" bytea,
    "CQ_HADOOP_JOB_ID" character varying(32),
    "CQ_ERROR_MESSAGE" text,
    "CQ_NEXT_TXN_ID" bigint,
    "CQ_TXN_ID" bigint,
    "CQ_COMMIT_TIME" bigint,
    "CQ_INITIATOR_ID" character varying(128),
    "CQ_INITIATOR_VERSION" character varying(128),
    "CQ_WORKER_VERSION" character varying(128),
    "CQ_CLEANER_START" bigint,
    "CQ_RETRY_RETENTION" bigint DEFAULT 0 NOT NULL,
    "CQ_POOL_NAME" character varying(128)
);


ALTER TABLE public."COMPACTION_QUEUE" OWNER TO admin;

--
-- Name: COMPLETED_COMPACTIONS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."COMPLETED_COMPACTIONS" (
    "CC_ID" bigint NOT NULL,
    "CC_DATABASE" character varying(128) NOT NULL,
    "CC_TABLE" character varying(256) NOT NULL,
    "CC_PARTITION" character varying(767),
    "CC_STATE" character(1) NOT NULL,
    "CC_TYPE" character(1) NOT NULL,
    "CC_TBLPROPERTIES" character varying(2048),
    "CC_WORKER_ID" character varying(128),
    "CC_ENQUEUE_TIME" bigint,
    "CC_START" bigint,
    "CC_END" bigint,
    "CC_RUN_AS" character varying(128),
    "CC_HIGHEST_WRITE_ID" bigint,
    "CC_META_INFO" bytea,
    "CC_HADOOP_JOB_ID" character varying(32),
    "CC_ERROR_MESSAGE" text,
    "CC_NEXT_TXN_ID" bigint,
    "CC_TXN_ID" bigint,
    "CC_COMMIT_TIME" bigint,
    "CC_INITIATOR_ID" character varying(128),
    "CC_INITIATOR_VERSION" character varying(128),
    "CC_WORKER_VERSION" character varying(128),
    "CC_POOL_NAME" character varying(128)
);


ALTER TABLE public."COMPLETED_COMPACTIONS" OWNER TO admin;

--
-- Name: COMPLETED_TXN_COMPONENTS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."COMPLETED_TXN_COMPONENTS" (
    "CTC_TXNID" bigint NOT NULL,
    "CTC_DATABASE" character varying(128) NOT NULL,
    "CTC_TABLE" character varying(256),
    "CTC_PARTITION" character varying(767),
    "CTC_TIMESTAMP" timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "CTC_WRITEID" bigint,
    "CTC_UPDATE_DELETE" character(1) NOT NULL
);


ALTER TABLE public."COMPLETED_TXN_COMPONENTS" OWNER TO admin;

--
-- Name: CTLGS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."CTLGS" (
    "CTLG_ID" bigint NOT NULL,
    "NAME" character varying(256),
    "DESC" character varying(4000),
    "LOCATION_URI" character varying(4000) NOT NULL,
    "CREATE_TIME" bigint
);


ALTER TABLE public."CTLGS" OWNER TO admin;

--
-- Name: DATABASE_PARAMS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."DATABASE_PARAMS" (
    "DB_ID" bigint NOT NULL,
    "PARAM_KEY" character varying(180) NOT NULL,
    "PARAM_VALUE" character varying(4000) DEFAULT NULL::character varying
);


ALTER TABLE public."DATABASE_PARAMS" OWNER TO admin;

--
-- Name: DATACONNECTORS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."DATACONNECTORS" (
    "NAME" character varying(128) NOT NULL,
    "TYPE" character varying(32) NOT NULL,
    "URL" character varying(4000) NOT NULL,
    "COMMENT" character varying(256),
    "OWNER_NAME" character varying(256),
    "OWNER_TYPE" character varying(10),
    "CREATE_TIME" integer NOT NULL
);


ALTER TABLE public."DATACONNECTORS" OWNER TO admin;

--
-- Name: DATACONNECTOR_PARAMS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."DATACONNECTOR_PARAMS" (
    "NAME" character varying(128) NOT NULL,
    "PARAM_KEY" character varying(180) NOT NULL,
    "PARAM_VALUE" character varying(4000)
);


ALTER TABLE public."DATACONNECTOR_PARAMS" OWNER TO admin;

--
-- Name: DBS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."DBS" (
    "DB_ID" bigint NOT NULL,
    "DESC" character varying(4000) DEFAULT NULL::character varying,
    "DB_LOCATION_URI" character varying(4000) NOT NULL,
    "NAME" character varying(128) DEFAULT NULL::character varying,
    "OWNER_NAME" character varying(128) DEFAULT NULL::character varying,
    "OWNER_TYPE" character varying(10) DEFAULT NULL::character varying,
    "CTLG_NAME" character varying(256) DEFAULT 'hive'::character varying NOT NULL,
    "CREATE_TIME" bigint,
    "DB_MANAGED_LOCATION_URI" character varying(4000),
    "TYPE" character varying(32) DEFAULT 'NATIVE'::character varying NOT NULL,
    "DATACONNECTOR_NAME" character varying(128),
    "REMOTE_DBNAME" character varying(128)
);


ALTER TABLE public."DBS" OWNER TO admin;

--
-- Name: DB_PRIVS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."DB_PRIVS" (
    "DB_GRANT_ID" bigint NOT NULL,
    "CREATE_TIME" bigint NOT NULL,
    "DB_ID" bigint,
    "GRANT_OPTION" smallint NOT NULL,
    "GRANTOR" character varying(128) DEFAULT NULL::character varying,
    "GRANTOR_TYPE" character varying(128) DEFAULT NULL::character varying,
    "PRINCIPAL_NAME" character varying(128) DEFAULT NULL::character varying,
    "PRINCIPAL_TYPE" character varying(128) DEFAULT NULL::character varying,
    "DB_PRIV" character varying(128) DEFAULT NULL::character varying,
    "AUTHORIZER" character varying(128) DEFAULT NULL::character varying
);


ALTER TABLE public."DB_PRIVS" OWNER TO admin;

--
-- Name: DC_PRIVS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."DC_PRIVS" (
    "DC_GRANT_ID" bigint NOT NULL,
    "CREATE_TIME" bigint NOT NULL,
    "NAME" character varying(128),
    "GRANT_OPTION" smallint NOT NULL,
    "GRANTOR" character varying(128) DEFAULT NULL::character varying,
    "GRANTOR_TYPE" character varying(128) DEFAULT NULL::character varying,
    "PRINCIPAL_NAME" character varying(128) DEFAULT NULL::character varying,
    "PRINCIPAL_TYPE" character varying(128) DEFAULT NULL::character varying,
    "DC_PRIV" character varying(128) DEFAULT NULL::character varying,
    "AUTHORIZER" character varying(128) DEFAULT NULL::character varying
);


ALTER TABLE public."DC_PRIVS" OWNER TO admin;

--
-- Name: DELEGATION_TOKENS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."DELEGATION_TOKENS" (
    "TOKEN_IDENT" character varying(767) NOT NULL,
    "TOKEN" character varying(767)
);


ALTER TABLE public."DELEGATION_TOKENS" OWNER TO admin;

--
-- Name: FUNCS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."FUNCS" (
    "FUNC_ID" bigint NOT NULL,
    "CLASS_NAME" character varying(4000),
    "CREATE_TIME" integer NOT NULL,
    "DB_ID" bigint,
    "FUNC_NAME" character varying(128),
    "FUNC_TYPE" integer NOT NULL,
    "OWNER_NAME" character varying(128),
    "OWNER_TYPE" character varying(10)
);


ALTER TABLE public."FUNCS" OWNER TO admin;

--
-- Name: FUNC_RU; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."FUNC_RU" (
    "FUNC_ID" bigint NOT NULL,
    "RESOURCE_TYPE" integer NOT NULL,
    "RESOURCE_URI" character varying(4000),
    "INTEGER_IDX" integer NOT NULL
);


ALTER TABLE public."FUNC_RU" OWNER TO admin;

--
-- Name: GLOBAL_PRIVS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."GLOBAL_PRIVS" (
    "USER_GRANT_ID" bigint NOT NULL,
    "CREATE_TIME" bigint NOT NULL,
    "GRANT_OPTION" smallint NOT NULL,
    "GRANTOR" character varying(128) DEFAULT NULL::character varying,
    "GRANTOR_TYPE" character varying(128) DEFAULT NULL::character varying,
    "PRINCIPAL_NAME" character varying(128) DEFAULT NULL::character varying,
    "PRINCIPAL_TYPE" character varying(128) DEFAULT NULL::character varying,
    "USER_PRIV" character varying(128) DEFAULT NULL::character varying,
    "AUTHORIZER" character varying(128) DEFAULT NULL::character varying
);


ALTER TABLE public."GLOBAL_PRIVS" OWNER TO admin;

--
-- Name: HIVE_LOCKS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."HIVE_LOCKS" (
    "HL_LOCK_EXT_ID" bigint NOT NULL,
    "HL_LOCK_INT_ID" bigint NOT NULL,
    "HL_TXNID" bigint NOT NULL,
    "HL_DB" character varying(128) NOT NULL,
    "HL_TABLE" character varying(256),
    "HL_PARTITION" character varying(767) DEFAULT NULL::character varying,
    "HL_LOCK_STATE" character(1) NOT NULL,
    "HL_LOCK_TYPE" character(1) NOT NULL,
    "HL_LAST_HEARTBEAT" bigint NOT NULL,
    "HL_ACQUIRED_AT" bigint,
    "HL_USER" character varying(128) NOT NULL,
    "HL_HOST" character varying(128) NOT NULL,
    "HL_HEARTBEAT_COUNT" integer,
    "HL_AGENT_INFO" character varying(128),
    "HL_BLOCKEDBY_EXT_ID" bigint,
    "HL_BLOCKEDBY_INT_ID" bigint
);


ALTER TABLE public."HIVE_LOCKS" OWNER TO admin;

--
-- Name: IDXS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."IDXS" (
    "INDEX_ID" bigint NOT NULL,
    "CREATE_TIME" bigint NOT NULL,
    "DEFERRED_REBUILD" boolean NOT NULL,
    "INDEX_HANDLER_CLASS" character varying(4000) DEFAULT NULL::character varying,
    "INDEX_NAME" character varying(128) DEFAULT NULL::character varying,
    "INDEX_TBL_ID" bigint,
    "LAST_ACCESS_TIME" bigint NOT NULL,
    "ORIG_TBL_ID" bigint,
    "SD_ID" bigint
);


ALTER TABLE public."IDXS" OWNER TO admin;

--
-- Name: INDEX_PARAMS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."INDEX_PARAMS" (
    "INDEX_ID" bigint NOT NULL,
    "PARAM_KEY" character varying(256) NOT NULL,
    "PARAM_VALUE" character varying(4000) DEFAULT NULL::character varying
);


ALTER TABLE public."INDEX_PARAMS" OWNER TO admin;

--
-- Name: I_SCHEMA; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."I_SCHEMA" (
    "SCHEMA_ID" bigint NOT NULL,
    "SCHEMA_TYPE" integer NOT NULL,
    "NAME" character varying(256),
    "DB_ID" bigint,
    "COMPATIBILITY" integer NOT NULL,
    "VALIDATION_LEVEL" integer NOT NULL,
    "CAN_EVOLVE" boolean NOT NULL,
    "SCHEMA_GROUP" character varying(256),
    "DESCRIPTION" character varying(4000)
);


ALTER TABLE public."I_SCHEMA" OWNER TO admin;

--
-- Name: KEY_CONSTRAINTS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."KEY_CONSTRAINTS" (
    "CHILD_CD_ID" bigint,
    "CHILD_INTEGER_IDX" bigint,
    "CHILD_TBL_ID" bigint,
    "PARENT_CD_ID" bigint,
    "PARENT_INTEGER_IDX" bigint NOT NULL,
    "PARENT_TBL_ID" bigint NOT NULL,
    "POSITION" bigint NOT NULL,
    "CONSTRAINT_NAME" character varying(400) NOT NULL,
    "CONSTRAINT_TYPE" smallint NOT NULL,
    "UPDATE_RULE" smallint,
    "DELETE_RULE" smallint,
    "ENABLE_VALIDATE_RELY" smallint NOT NULL,
    "DEFAULT_VALUE" character varying(400)
);


ALTER TABLE public."KEY_CONSTRAINTS" OWNER TO admin;

--
-- Name: MASTER_KEYS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."MASTER_KEYS" (
    "KEY_ID" integer NOT NULL,
    "MASTER_KEY" character varying(767)
);


ALTER TABLE public."MASTER_KEYS" OWNER TO admin;

--
-- Name: MASTER_KEYS_KEY_ID_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."MASTER_KEYS_KEY_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."MASTER_KEYS_KEY_ID_seq" OWNER TO admin;

--
-- Name: MASTER_KEYS_KEY_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."MASTER_KEYS_KEY_ID_seq" OWNED BY public."MASTER_KEYS"."KEY_ID";


--
-- Name: MATERIALIZATION_REBUILD_LOCKS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."MATERIALIZATION_REBUILD_LOCKS" (
    "MRL_TXN_ID" bigint NOT NULL,
    "MRL_DB_NAME" character varying(128) NOT NULL,
    "MRL_TBL_NAME" character varying(256) NOT NULL,
    "MRL_LAST_HEARTBEAT" bigint NOT NULL
);


ALTER TABLE public."MATERIALIZATION_REBUILD_LOCKS" OWNER TO admin;

--
-- Name: METASTORE_DB_PROPERTIES; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."METASTORE_DB_PROPERTIES" (
    "PROPERTY_KEY" character varying(255) NOT NULL,
    "PROPERTY_VALUE" character varying(1000) NOT NULL,
    "DESCRIPTION" character varying(1000)
);


ALTER TABLE public."METASTORE_DB_PROPERTIES" OWNER TO admin;

--
-- Name: MIN_HISTORY_LEVEL; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."MIN_HISTORY_LEVEL" (
    "MHL_TXNID" bigint NOT NULL,
    "MHL_MIN_OPEN_TXNID" bigint NOT NULL
);


ALTER TABLE public."MIN_HISTORY_LEVEL" OWNER TO admin;

--
-- Name: MV_CREATION_METADATA; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."MV_CREATION_METADATA" (
    "MV_CREATION_METADATA_ID" bigint NOT NULL,
    "CAT_NAME" character varying(256) NOT NULL,
    "DB_NAME" character varying(128) NOT NULL,
    "TBL_NAME" character varying(256) NOT NULL,
    "TXN_LIST" text,
    "MATERIALIZATION_TIME" bigint NOT NULL
);


ALTER TABLE public."MV_CREATION_METADATA" OWNER TO admin;

--
-- Name: MV_TABLES_USED; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."MV_TABLES_USED" (
    "MV_CREATION_METADATA_ID" bigint NOT NULL,
    "TBL_ID" bigint NOT NULL,
    "INSERTED_COUNT" bigint DEFAULT 0 NOT NULL,
    "UPDATED_COUNT" bigint DEFAULT 0 NOT NULL,
    "DELETED_COUNT" bigint DEFAULT 0 NOT NULL
);


ALTER TABLE public."MV_TABLES_USED" OWNER TO admin;

--
-- Name: NEXT_COMPACTION_QUEUE_ID; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."NEXT_COMPACTION_QUEUE_ID" (
    "NCQ_NEXT" bigint NOT NULL
);


ALTER TABLE public."NEXT_COMPACTION_QUEUE_ID" OWNER TO admin;

--
-- Name: NEXT_LOCK_ID; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."NEXT_LOCK_ID" (
    "NL_NEXT" bigint NOT NULL
);


ALTER TABLE public."NEXT_LOCK_ID" OWNER TO admin;

--
-- Name: NEXT_WRITE_ID; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."NEXT_WRITE_ID" (
    "NWI_DATABASE" character varying(128) NOT NULL,
    "NWI_TABLE" character varying(256) NOT NULL,
    "NWI_NEXT" bigint NOT NULL
);


ALTER TABLE public."NEXT_WRITE_ID" OWNER TO admin;

--
-- Name: NOTIFICATION_LOG; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."NOTIFICATION_LOG" (
    "NL_ID" bigint NOT NULL,
    "EVENT_ID" bigint NOT NULL,
    "EVENT_TIME" integer NOT NULL,
    "EVENT_TYPE" character varying(32) NOT NULL,
    "CAT_NAME" character varying(256),
    "DB_NAME" character varying(128),
    "TBL_NAME" character varying(256),
    "MESSAGE" text,
    "MESSAGE_FORMAT" character varying(16)
);


ALTER TABLE public."NOTIFICATION_LOG" OWNER TO admin;

--
-- Name: NOTIFICATION_SEQUENCE; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."NOTIFICATION_SEQUENCE" (
    "NNI_ID" bigint NOT NULL,
    "NEXT_EVENT_ID" bigint NOT NULL,
    CONSTRAINT "ONE_ROW_CONSTRAINT" CHECK (("NNI_ID" = 1))
);


ALTER TABLE public."NOTIFICATION_SEQUENCE" OWNER TO admin;

--
-- Name: NUCLEUS_TABLES; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."NUCLEUS_TABLES" (
    "CLASS_NAME" character varying(128) NOT NULL,
    "TABLE_NAME" character varying(128) NOT NULL,
    "TYPE" character varying(4) NOT NULL,
    "OWNER" character varying(2) NOT NULL,
    "VERSION" character varying(20) NOT NULL,
    "INTERFACE_NAME" character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public."NUCLEUS_TABLES" OWNER TO admin;

--
-- Name: PACKAGES; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."PACKAGES" (
    "PKG_ID" bigint NOT NULL,
    "CREATE_TIME" integer NOT NULL,
    "DB_ID" bigint NOT NULL,
    "NAME" character varying(256) NOT NULL,
    "OWNER_NAME" character varying(128) NOT NULL,
    "HEADER" text NOT NULL,
    "BODY" text NOT NULL
);


ALTER TABLE public."PACKAGES" OWNER TO admin;

--
-- Name: PARTITIONS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."PARTITIONS" (
    "PART_ID" bigint NOT NULL,
    "CREATE_TIME" bigint NOT NULL,
    "LAST_ACCESS_TIME" bigint NOT NULL,
    "PART_NAME" character varying(767) DEFAULT NULL::character varying,
    "SD_ID" bigint,
    "TBL_ID" bigint,
    "WRITE_ID" bigint DEFAULT 0
);


ALTER TABLE public."PARTITIONS" OWNER TO admin;

--
-- Name: PARTITION_EVENTS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."PARTITION_EVENTS" (
    "PART_NAME_ID" bigint NOT NULL,
    "CAT_NAME" character varying(256),
    "DB_NAME" character varying(128),
    "EVENT_TIME" bigint NOT NULL,
    "EVENT_TYPE" integer NOT NULL,
    "PARTITION_NAME" character varying(767),
    "TBL_NAME" character varying(256)
);


ALTER TABLE public."PARTITION_EVENTS" OWNER TO admin;

--
-- Name: PARTITION_KEYS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."PARTITION_KEYS" (
    "TBL_ID" bigint NOT NULL,
    "PKEY_COMMENT" character varying(4000) DEFAULT NULL::character varying,
    "PKEY_NAME" character varying(128) NOT NULL,
    "PKEY_TYPE" character varying(767) NOT NULL,
    "INTEGER_IDX" bigint NOT NULL
);


ALTER TABLE public."PARTITION_KEYS" OWNER TO admin;

--
-- Name: PARTITION_KEY_VALS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."PARTITION_KEY_VALS" (
    "PART_ID" bigint NOT NULL,
    "PART_KEY_VAL" character varying(256) DEFAULT NULL::character varying,
    "INTEGER_IDX" bigint NOT NULL
);


ALTER TABLE public."PARTITION_KEY_VALS" OWNER TO admin;

--
-- Name: PARTITION_PARAMS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."PARTITION_PARAMS" (
    "PART_ID" bigint NOT NULL,
    "PARAM_KEY" character varying(256) NOT NULL,
    "PARAM_VALUE" text
);


ALTER TABLE public."PARTITION_PARAMS" OWNER TO admin;

--
-- Name: PART_COL_PRIVS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."PART_COL_PRIVS" (
    "PART_COLUMN_GRANT_ID" bigint NOT NULL,
    "COLUMN_NAME" character varying(767) DEFAULT NULL::character varying,
    "CREATE_TIME" bigint NOT NULL,
    "GRANT_OPTION" smallint NOT NULL,
    "GRANTOR" character varying(128) DEFAULT NULL::character varying,
    "GRANTOR_TYPE" character varying(128) DEFAULT NULL::character varying,
    "PART_ID" bigint,
    "PRINCIPAL_NAME" character varying(128) DEFAULT NULL::character varying,
    "PRINCIPAL_TYPE" character varying(128) DEFAULT NULL::character varying,
    "PART_COL_PRIV" character varying(128) DEFAULT NULL::character varying,
    "AUTHORIZER" character varying(128) DEFAULT NULL::character varying
);


ALTER TABLE public."PART_COL_PRIVS" OWNER TO admin;

--
-- Name: PART_COL_STATS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."PART_COL_STATS" (
    "CS_ID" bigint NOT NULL,
    "CAT_NAME" character varying(256) DEFAULT NULL::character varying,
    "DB_NAME" character varying(128) DEFAULT NULL::character varying,
    "TABLE_NAME" character varying(256) DEFAULT NULL::character varying,
    "PARTITION_NAME" character varying(767) DEFAULT NULL::character varying,
    "COLUMN_NAME" character varying(767) DEFAULT NULL::character varying,
    "COLUMN_TYPE" character varying(128) DEFAULT NULL::character varying,
    "PART_ID" bigint NOT NULL,
    "LONG_LOW_VALUE" bigint,
    "LONG_HIGH_VALUE" bigint,
    "DOUBLE_LOW_VALUE" double precision,
    "DOUBLE_HIGH_VALUE" double precision,
    "BIG_DECIMAL_LOW_VALUE" character varying(4000) DEFAULT NULL::character varying,
    "BIG_DECIMAL_HIGH_VALUE" character varying(4000) DEFAULT NULL::character varying,
    "NUM_NULLS" bigint NOT NULL,
    "NUM_DISTINCTS" bigint,
    "BIT_VECTOR" bytea,
    "AVG_COL_LEN" double precision,
    "MAX_COL_LEN" bigint,
    "NUM_TRUES" bigint,
    "NUM_FALSES" bigint,
    "LAST_ANALYZED" bigint NOT NULL,
    "ENGINE" character varying(128) NOT NULL
);


ALTER TABLE public."PART_COL_STATS" OWNER TO admin;

--
-- Name: PART_PRIVS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."PART_PRIVS" (
    "PART_GRANT_ID" bigint NOT NULL,
    "CREATE_TIME" bigint NOT NULL,
    "GRANT_OPTION" smallint NOT NULL,
    "GRANTOR" character varying(128) DEFAULT NULL::character varying,
    "GRANTOR_TYPE" character varying(128) DEFAULT NULL::character varying,
    "PART_ID" bigint,
    "PRINCIPAL_NAME" character varying(128) DEFAULT NULL::character varying,
    "PRINCIPAL_TYPE" character varying(128) DEFAULT NULL::character varying,
    "PART_PRIV" character varying(128) DEFAULT NULL::character varying,
    "AUTHORIZER" character varying(128) DEFAULT NULL::character varying
);


ALTER TABLE public."PART_PRIVS" OWNER TO admin;

--
-- Name: REPLICATION_METRICS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."REPLICATION_METRICS" (
    "RM_SCHEDULED_EXECUTION_ID" bigint NOT NULL,
    "RM_POLICY" character varying(256) NOT NULL,
    "RM_DUMP_EXECUTION_ID" bigint NOT NULL,
    "RM_METADATA" character varying(4000),
    "RM_PROGRESS" character varying(10000),
    "RM_START_TIME" integer NOT NULL,
    "MESSAGE_FORMAT" character varying(16) DEFAULT 'json-0.2'::character varying
);


ALTER TABLE public."REPLICATION_METRICS" OWNER TO admin;

--
-- Name: REPL_TXN_MAP; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."REPL_TXN_MAP" (
    "RTM_REPL_POLICY" character varying(256) NOT NULL,
    "RTM_SRC_TXN_ID" bigint NOT NULL,
    "RTM_TARGET_TXN_ID" bigint NOT NULL
);


ALTER TABLE public."REPL_TXN_MAP" OWNER TO admin;

--
-- Name: ROLES; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."ROLES" (
    "ROLE_ID" bigint NOT NULL,
    "CREATE_TIME" bigint NOT NULL,
    "OWNER_NAME" character varying(128) DEFAULT NULL::character varying,
    "ROLE_NAME" character varying(128) DEFAULT NULL::character varying
);


ALTER TABLE public."ROLES" OWNER TO admin;

--
-- Name: ROLE_MAP; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."ROLE_MAP" (
    "ROLE_GRANT_ID" bigint NOT NULL,
    "ADD_TIME" bigint NOT NULL,
    "GRANT_OPTION" smallint NOT NULL,
    "GRANTOR" character varying(128) DEFAULT NULL::character varying,
    "GRANTOR_TYPE" character varying(128) DEFAULT NULL::character varying,
    "PRINCIPAL_NAME" character varying(128) DEFAULT NULL::character varying,
    "PRINCIPAL_TYPE" character varying(128) DEFAULT NULL::character varying,
    "ROLE_ID" bigint
);


ALTER TABLE public."ROLE_MAP" OWNER TO admin;

--
-- Name: RUNTIME_STATS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."RUNTIME_STATS" (
    "RS_ID" bigint NOT NULL,
    "CREATE_TIME" bigint NOT NULL,
    "WEIGHT" bigint NOT NULL,
    "PAYLOAD" bytea
);


ALTER TABLE public."RUNTIME_STATS" OWNER TO admin;

--
-- Name: SCHEDULED_EXECUTIONS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."SCHEDULED_EXECUTIONS" (
    "SCHEDULED_EXECUTION_ID" bigint NOT NULL,
    "END_TIME" integer,
    "ERROR_MESSAGE" character varying(2000),
    "EXECUTOR_QUERY_ID" character varying(256),
    "LAST_UPDATE_TIME" integer,
    "SCHEDULED_QUERY_ID" bigint,
    "START_TIME" integer,
    "STATE" character varying(256)
);


ALTER TABLE public."SCHEDULED_EXECUTIONS" OWNER TO admin;

--
-- Name: SCHEDULED_QUERIES; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."SCHEDULED_QUERIES" (
    "SCHEDULED_QUERY_ID" bigint NOT NULL,
    "CLUSTER_NAMESPACE" character varying(256),
    "ENABLED" boolean NOT NULL,
    "NEXT_EXECUTION" integer,
    "QUERY" character varying(4000),
    "SCHEDULE" character varying(256),
    "SCHEDULE_NAME" character varying(256),
    "USER" character varying(256),
    "ACTIVE_EXECUTION_ID" bigint
);


ALTER TABLE public."SCHEDULED_QUERIES" OWNER TO admin;

--
-- Name: SCHEMA_VERSION; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."SCHEMA_VERSION" (
    "SCHEMA_VERSION_ID" bigint NOT NULL,
    "SCHEMA_ID" bigint,
    "VERSION" integer NOT NULL,
    "CREATED_AT" bigint NOT NULL,
    "CD_ID" bigint,
    "STATE" integer NOT NULL,
    "DESCRIPTION" character varying(4000),
    "SCHEMA_TEXT" text,
    "FINGERPRINT" character varying(256),
    "SCHEMA_VERSION_NAME" character varying(256),
    "SERDE_ID" bigint
);


ALTER TABLE public."SCHEMA_VERSION" OWNER TO admin;

--
-- Name: SDS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."SDS" (
    "SD_ID" bigint NOT NULL,
    "INPUT_FORMAT" character varying(4000) DEFAULT NULL::character varying,
    "IS_COMPRESSED" boolean NOT NULL,
    "LOCATION" character varying(4000) DEFAULT NULL::character varying,
    "NUM_BUCKETS" bigint NOT NULL,
    "OUTPUT_FORMAT" character varying(4000) DEFAULT NULL::character varying,
    "SERDE_ID" bigint,
    "CD_ID" bigint,
    "IS_STOREDASSUBDIRECTORIES" boolean NOT NULL
);


ALTER TABLE public."SDS" OWNER TO admin;

--
-- Name: SD_PARAMS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."SD_PARAMS" (
    "SD_ID" bigint NOT NULL,
    "PARAM_KEY" character varying(256) NOT NULL,
    "PARAM_VALUE" text
);


ALTER TABLE public."SD_PARAMS" OWNER TO admin;

--
-- Name: SEQUENCE_TABLE; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."SEQUENCE_TABLE" (
    "SEQUENCE_NAME" character varying(255) NOT NULL,
    "NEXT_VAL" bigint NOT NULL
);


ALTER TABLE public."SEQUENCE_TABLE" OWNER TO admin;

--
-- Name: SERDES; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."SERDES" (
    "SERDE_ID" bigint NOT NULL,
    "NAME" character varying(128) DEFAULT NULL::character varying,
    "SLIB" character varying(4000) DEFAULT NULL::character varying,
    "DESCRIPTION" character varying(4000),
    "SERIALIZER_CLASS" character varying(4000),
    "DESERIALIZER_CLASS" character varying(4000),
    "SERDE_TYPE" integer
);


ALTER TABLE public."SERDES" OWNER TO admin;

--
-- Name: SERDE_PARAMS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."SERDE_PARAMS" (
    "SERDE_ID" bigint NOT NULL,
    "PARAM_KEY" character varying(256) NOT NULL,
    "PARAM_VALUE" text
);


ALTER TABLE public."SERDE_PARAMS" OWNER TO admin;

--
-- Name: SKEWED_COL_NAMES; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."SKEWED_COL_NAMES" (
    "SD_ID" bigint NOT NULL,
    "SKEWED_COL_NAME" character varying(256) DEFAULT NULL::character varying,
    "INTEGER_IDX" bigint NOT NULL
);


ALTER TABLE public."SKEWED_COL_NAMES" OWNER TO admin;

--
-- Name: SKEWED_COL_VALUE_LOC_MAP; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."SKEWED_COL_VALUE_LOC_MAP" (
    "SD_ID" bigint NOT NULL,
    "STRING_LIST_ID_KID" bigint NOT NULL,
    "LOCATION" character varying(4000) DEFAULT NULL::character varying
);


ALTER TABLE public."SKEWED_COL_VALUE_LOC_MAP" OWNER TO admin;

--
-- Name: SKEWED_STRING_LIST; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."SKEWED_STRING_LIST" (
    "STRING_LIST_ID" bigint NOT NULL
);


ALTER TABLE public."SKEWED_STRING_LIST" OWNER TO admin;

--
-- Name: SKEWED_STRING_LIST_VALUES; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."SKEWED_STRING_LIST_VALUES" (
    "STRING_LIST_ID" bigint NOT NULL,
    "STRING_LIST_VALUE" character varying(256) DEFAULT NULL::character varying,
    "INTEGER_IDX" bigint NOT NULL
);


ALTER TABLE public."SKEWED_STRING_LIST_VALUES" OWNER TO admin;

--
-- Name: SKEWED_VALUES; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."SKEWED_VALUES" (
    "SD_ID_OID" bigint NOT NULL,
    "STRING_LIST_ID_EID" bigint NOT NULL,
    "INTEGER_IDX" bigint NOT NULL
);


ALTER TABLE public."SKEWED_VALUES" OWNER TO admin;

--
-- Name: SORT_COLS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."SORT_COLS" (
    "SD_ID" bigint NOT NULL,
    "COLUMN_NAME" character varying(767) DEFAULT NULL::character varying,
    "ORDER" bigint NOT NULL,
    "INTEGER_IDX" bigint NOT NULL
);


ALTER TABLE public."SORT_COLS" OWNER TO admin;

--
-- Name: STORED_PROCS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."STORED_PROCS" (
    "SP_ID" bigint NOT NULL,
    "CREATE_TIME" integer NOT NULL,
    "DB_ID" bigint NOT NULL,
    "NAME" character varying(256) NOT NULL,
    "OWNER_NAME" character varying(128) NOT NULL,
    "SOURCE" text NOT NULL
);


ALTER TABLE public."STORED_PROCS" OWNER TO admin;

--
-- Name: TABLE_PARAMS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."TABLE_PARAMS" (
    "TBL_ID" bigint NOT NULL,
    "PARAM_KEY" character varying(256) NOT NULL,
    "PARAM_VALUE" text
);


ALTER TABLE public."TABLE_PARAMS" OWNER TO admin;

--
-- Name: TAB_COL_STATS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."TAB_COL_STATS" (
    "CS_ID" bigint NOT NULL,
    "CAT_NAME" character varying(256) DEFAULT NULL::character varying,
    "DB_NAME" character varying(128) DEFAULT NULL::character varying,
    "TABLE_NAME" character varying(256) DEFAULT NULL::character varying,
    "COLUMN_NAME" character varying(767) DEFAULT NULL::character varying,
    "COLUMN_TYPE" character varying(128) DEFAULT NULL::character varying,
    "TBL_ID" bigint NOT NULL,
    "LONG_LOW_VALUE" bigint,
    "LONG_HIGH_VALUE" bigint,
    "DOUBLE_LOW_VALUE" double precision,
    "DOUBLE_HIGH_VALUE" double precision,
    "BIG_DECIMAL_LOW_VALUE" character varying(4000) DEFAULT NULL::character varying,
    "BIG_DECIMAL_HIGH_VALUE" character varying(4000) DEFAULT NULL::character varying,
    "NUM_NULLS" bigint NOT NULL,
    "NUM_DISTINCTS" bigint,
    "BIT_VECTOR" bytea,
    "AVG_COL_LEN" double precision,
    "MAX_COL_LEN" bigint,
    "NUM_TRUES" bigint,
    "NUM_FALSES" bigint,
    "LAST_ANALYZED" bigint NOT NULL,
    "ENGINE" character varying(128) NOT NULL
);


ALTER TABLE public."TAB_COL_STATS" OWNER TO admin;

--
-- Name: TBLS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."TBLS" (
    "TBL_ID" bigint NOT NULL,
    "CREATE_TIME" bigint NOT NULL,
    "DB_ID" bigint,
    "LAST_ACCESS_TIME" bigint NOT NULL,
    "OWNER" character varying(767) DEFAULT NULL::character varying,
    "OWNER_TYPE" character varying(10) DEFAULT NULL::character varying,
    "RETENTION" bigint NOT NULL,
    "SD_ID" bigint,
    "TBL_NAME" character varying(256) DEFAULT NULL::character varying,
    "TBL_TYPE" character varying(128) DEFAULT NULL::character varying,
    "VIEW_EXPANDED_TEXT" text,
    "VIEW_ORIGINAL_TEXT" text,
    "IS_REWRITE_ENABLED" boolean DEFAULT false NOT NULL,
    "WRITE_ID" bigint DEFAULT 0
);


ALTER TABLE public."TBLS" OWNER TO admin;

--
-- Name: TBL_COL_PRIVS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."TBL_COL_PRIVS" (
    "TBL_COLUMN_GRANT_ID" bigint NOT NULL,
    "COLUMN_NAME" character varying(767) DEFAULT NULL::character varying,
    "CREATE_TIME" bigint NOT NULL,
    "GRANT_OPTION" smallint NOT NULL,
    "GRANTOR" character varying(128) DEFAULT NULL::character varying,
    "GRANTOR_TYPE" character varying(128) DEFAULT NULL::character varying,
    "PRINCIPAL_NAME" character varying(128) DEFAULT NULL::character varying,
    "PRINCIPAL_TYPE" character varying(128) DEFAULT NULL::character varying,
    "TBL_COL_PRIV" character varying(128) DEFAULT NULL::character varying,
    "TBL_ID" bigint,
    "AUTHORIZER" character varying(128) DEFAULT NULL::character varying
);


ALTER TABLE public."TBL_COL_PRIVS" OWNER TO admin;

--
-- Name: TBL_PRIVS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."TBL_PRIVS" (
    "TBL_GRANT_ID" bigint NOT NULL,
    "CREATE_TIME" bigint NOT NULL,
    "GRANT_OPTION" smallint NOT NULL,
    "GRANTOR" character varying(128) DEFAULT NULL::character varying,
    "GRANTOR_TYPE" character varying(128) DEFAULT NULL::character varying,
    "PRINCIPAL_NAME" character varying(128) DEFAULT NULL::character varying,
    "PRINCIPAL_TYPE" character varying(128) DEFAULT NULL::character varying,
    "TBL_PRIV" character varying(128) DEFAULT NULL::character varying,
    "TBL_ID" bigint,
    "AUTHORIZER" character varying(128) DEFAULT NULL::character varying
);


ALTER TABLE public."TBL_PRIVS" OWNER TO admin;

--
-- Name: TXNS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."TXNS" (
    "TXN_ID" bigint NOT NULL,
    "TXN_STATE" character(1) NOT NULL,
    "TXN_STARTED" bigint NOT NULL,
    "TXN_LAST_HEARTBEAT" bigint NOT NULL,
    "TXN_USER" character varying(128) NOT NULL,
    "TXN_HOST" character varying(128) NOT NULL,
    "TXN_AGENT_INFO" character varying(128),
    "TXN_META_INFO" character varying(128),
    "TXN_HEARTBEAT_COUNT" integer,
    "TXN_TYPE" integer
);


ALTER TABLE public."TXNS" OWNER TO admin;

--
-- Name: TXNS_TXN_ID_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public."TXNS_TXN_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."TXNS_TXN_ID_seq" OWNER TO admin;

--
-- Name: TXNS_TXN_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public."TXNS_TXN_ID_seq" OWNED BY public."TXNS"."TXN_ID";


--
-- Name: TXN_COMPONENTS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."TXN_COMPONENTS" (
    "TC_TXNID" bigint NOT NULL,
    "TC_DATABASE" character varying(128) NOT NULL,
    "TC_TABLE" character varying(256),
    "TC_PARTITION" character varying(767) DEFAULT NULL::character varying,
    "TC_OPERATION_TYPE" character(1) NOT NULL,
    "TC_WRITEID" bigint
);


ALTER TABLE public."TXN_COMPONENTS" OWNER TO admin;

--
-- Name: TXN_LOCK_TBL; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."TXN_LOCK_TBL" (
    "TXN_LOCK" bigint NOT NULL
);


ALTER TABLE public."TXN_LOCK_TBL" OWNER TO admin;

--
-- Name: TXN_TO_WRITE_ID; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."TXN_TO_WRITE_ID" (
    "T2W_TXNID" bigint NOT NULL,
    "T2W_DATABASE" character varying(128) NOT NULL,
    "T2W_TABLE" character varying(256) NOT NULL,
    "T2W_WRITEID" bigint NOT NULL
);


ALTER TABLE public."TXN_TO_WRITE_ID" OWNER TO admin;

--
-- Name: TXN_WRITE_NOTIFICATION_LOG; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."TXN_WRITE_NOTIFICATION_LOG" (
    "WNL_ID" bigint NOT NULL,
    "WNL_TXNID" bigint NOT NULL,
    "WNL_WRITEID" bigint NOT NULL,
    "WNL_DATABASE" character varying(128) NOT NULL,
    "WNL_TABLE" character varying(256) NOT NULL,
    "WNL_PARTITION" character varying(767) NOT NULL,
    "WNL_TABLE_OBJ" text NOT NULL,
    "WNL_PARTITION_OBJ" text,
    "WNL_FILES" text,
    "WNL_EVENT_TIME" integer NOT NULL
);


ALTER TABLE public."TXN_WRITE_NOTIFICATION_LOG" OWNER TO admin;

--
-- Name: TYPES; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."TYPES" (
    "TYPES_ID" bigint NOT NULL,
    "TYPE_NAME" character varying(128) DEFAULT NULL::character varying,
    "TYPE1" character varying(767) DEFAULT NULL::character varying,
    "TYPE2" character varying(767) DEFAULT NULL::character varying
);


ALTER TABLE public."TYPES" OWNER TO admin;

--
-- Name: TYPE_FIELDS; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."TYPE_FIELDS" (
    "TYPE_NAME" bigint NOT NULL,
    "COMMENT" character varying(256) DEFAULT NULL::character varying,
    "FIELD_NAME" character varying(128) NOT NULL,
    "FIELD_TYPE" character varying(767) NOT NULL,
    "INTEGER_IDX" bigint NOT NULL
);


ALTER TABLE public."TYPE_FIELDS" OWNER TO admin;

--
-- Name: VERSION; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."VERSION" (
    "VER_ID" bigint NOT NULL,
    "SCHEMA_VERSION" character varying(127) NOT NULL,
    "VERSION_COMMENT" character varying(255) NOT NULL
);


ALTER TABLE public."VERSION" OWNER TO admin;

--
-- Name: WM_MAPPING; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."WM_MAPPING" (
    "MAPPING_ID" bigint NOT NULL,
    "RP_ID" bigint NOT NULL,
    "ENTITY_TYPE" character varying(128) NOT NULL,
    "ENTITY_NAME" character varying(128) NOT NULL,
    "POOL_ID" bigint,
    "ORDERING" integer
);


ALTER TABLE public."WM_MAPPING" OWNER TO admin;

--
-- Name: WM_POOL; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."WM_POOL" (
    "POOL_ID" bigint NOT NULL,
    "RP_ID" bigint NOT NULL,
    "PATH" character varying(1024) NOT NULL,
    "ALLOC_FRACTION" double precision,
    "QUERY_PARALLELISM" integer,
    "SCHEDULING_POLICY" character varying(1024)
);


ALTER TABLE public."WM_POOL" OWNER TO admin;

--
-- Name: WM_POOL_TO_TRIGGER; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."WM_POOL_TO_TRIGGER" (
    "POOL_ID" bigint NOT NULL,
    "TRIGGER_ID" bigint NOT NULL
);


ALTER TABLE public."WM_POOL_TO_TRIGGER" OWNER TO admin;

--
-- Name: WM_RESOURCEPLAN; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."WM_RESOURCEPLAN" (
    "RP_ID" bigint NOT NULL,
    "NAME" character varying(128) NOT NULL,
    "NS" character varying(128),
    "QUERY_PARALLELISM" integer,
    "STATUS" character varying(20) NOT NULL,
    "DEFAULT_POOL_ID" bigint
);


ALTER TABLE public."WM_RESOURCEPLAN" OWNER TO admin;

--
-- Name: WM_TRIGGER; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."WM_TRIGGER" (
    "TRIGGER_ID" bigint NOT NULL,
    "RP_ID" bigint NOT NULL,
    "NAME" character varying(128) NOT NULL,
    "TRIGGER_EXPRESSION" character varying(1024) DEFAULT NULL::character varying,
    "ACTION_EXPRESSION" character varying(1024) DEFAULT NULL::character varying,
    "IS_IN_UNMANAGED" smallint DEFAULT 0 NOT NULL
);


ALTER TABLE public."WM_TRIGGER" OWNER TO admin;

--
-- Name: WRITE_SET; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public."WRITE_SET" (
    "WS_DATABASE" character varying(128) NOT NULL,
    "WS_TABLE" character varying(256) NOT NULL,
    "WS_PARTITION" character varying(767),
    "WS_TXNID" bigint NOT NULL,
    "WS_COMMIT_ID" bigint NOT NULL,
    "WS_OPERATION_TYPE" character(1) NOT NULL
);


ALTER TABLE public."WRITE_SET" OWNER TO admin;

--
-- Name: MASTER_KEYS KEY_ID; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."MASTER_KEYS" ALTER COLUMN "KEY_ID" SET DEFAULT nextval('public."MASTER_KEYS_KEY_ID_seq"'::regclass);


--
-- Name: TXNS TXN_ID; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TXNS" ALTER COLUMN "TXN_ID" SET DEFAULT nextval('public."TXNS_TXN_ID_seq"'::regclass);


--
-- Data for Name: AUX_TABLE; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3859.dat

--
-- Data for Name: BUCKETING_COLS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3791.dat

--
-- Data for Name: CDS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3792.dat

--
-- Data for Name: COLUMNS_V2; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3793.dat

--
-- Data for Name: COMPACTION_METRICS_CACHE; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3858.dat

--
-- Data for Name: COMPACTION_QUEUE; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3855.dat

--
-- Data for Name: COMPLETED_COMPACTIONS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3857.dat

--
-- Data for Name: COMPLETED_TXN_COMPONENTS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3851.dat

--
-- Data for Name: CTLGS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3795.dat

--
-- Data for Name: DATABASE_PARAMS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3794.dat

--
-- Data for Name: DATACONNECTORS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3875.dat

--
-- Data for Name: DATACONNECTOR_PARAMS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3876.dat

--
-- Data for Name: DBS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3796.dat

--
-- Data for Name: DB_PRIVS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3797.dat

--
-- Data for Name: DC_PRIVS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3798.dat

--
-- Data for Name: DELEGATION_TOKENS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3833.dat

--
-- Data for Name: FUNCS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3837.dat

--
-- Data for Name: FUNC_RU; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3838.dat

--
-- Data for Name: GLOBAL_PRIVS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3799.dat

--
-- Data for Name: HIVE_LOCKS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3853.dat

--
-- Data for Name: IDXS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3800.dat

--
-- Data for Name: INDEX_PARAMS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3801.dat

--
-- Data for Name: I_SCHEMA; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3865.dat

--
-- Data for Name: KEY_CONSTRAINTS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3841.dat

--
-- Data for Name: MASTER_KEYS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3832.dat

--
-- Data for Name: MATERIALIZATION_REBUILD_LOCKS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3864.dat

--
-- Data for Name: METASTORE_DB_PROPERTIES; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3842.dat

--
-- Data for Name: MIN_HISTORY_LEVEL; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3863.dat

--
-- Data for Name: MV_CREATION_METADATA; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3820.dat

--
-- Data for Name: MV_TABLES_USED; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3821.dat

--
-- Data for Name: NEXT_COMPACTION_QUEUE_ID; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3856.dat

--
-- Data for Name: NEXT_LOCK_ID; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3854.dat

--
-- Data for Name: NEXT_WRITE_ID; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3862.dat

--
-- Data for Name: NOTIFICATION_LOG; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3839.dat

--
-- Data for Name: NOTIFICATION_SEQUENCE; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3840.dat

--
-- Data for Name: NUCLEUS_TABLES; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3802.dat

--
-- Data for Name: PACKAGES; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3874.dat

--
-- Data for Name: PARTITIONS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3803.dat

--
-- Data for Name: PARTITION_EVENTS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3804.dat

--
-- Data for Name: PARTITION_KEYS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3805.dat

--
-- Data for Name: PARTITION_KEY_VALS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3806.dat

--
-- Data for Name: PARTITION_PARAMS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3807.dat

--
-- Data for Name: PART_COL_PRIVS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3808.dat

--
-- Data for Name: PART_COL_STATS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3836.dat

--
-- Data for Name: PART_PRIVS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3809.dat

--
-- Data for Name: REPLICATION_METRICS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3872.dat

--
-- Data for Name: REPL_TXN_MAP; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3867.dat

--
-- Data for Name: ROLES; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3810.dat

--
-- Data for Name: ROLE_MAP; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3811.dat

--
-- Data for Name: RUNTIME_STATS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3868.dat

--
-- Data for Name: SCHEDULED_EXECUTIONS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3871.dat

--
-- Data for Name: SCHEDULED_QUERIES; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3870.dat

--
-- Data for Name: SCHEMA_VERSION; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3866.dat

--
-- Data for Name: SDS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3812.dat

--
-- Data for Name: SD_PARAMS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3813.dat

--
-- Data for Name: SEQUENCE_TABLE; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3814.dat

--
-- Data for Name: SERDES; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3815.dat

--
-- Data for Name: SERDE_PARAMS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3816.dat

--
-- Data for Name: SKEWED_COL_NAMES; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3828.dat

--
-- Data for Name: SKEWED_COL_VALUE_LOC_MAP; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3829.dat

--
-- Data for Name: SKEWED_STRING_LIST; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3826.dat

--
-- Data for Name: SKEWED_STRING_LIST_VALUES; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3827.dat

--
-- Data for Name: SKEWED_VALUES; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3830.dat

--
-- Data for Name: SORT_COLS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3817.dat

--
-- Data for Name: STORED_PROCS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3873.dat

--
-- Data for Name: TABLE_PARAMS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3818.dat

--
-- Data for Name: TAB_COL_STATS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3834.dat

--
-- Data for Name: TBLS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3819.dat

--
-- Data for Name: TBL_COL_PRIVS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3822.dat

--
-- Data for Name: TBL_PRIVS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3823.dat

--
-- Data for Name: TXNS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3849.dat

--
-- Data for Name: TXN_COMPONENTS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3850.dat

--
-- Data for Name: TXN_LOCK_TBL; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3852.dat

--
-- Data for Name: TXN_TO_WRITE_ID; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3861.dat

--
-- Data for Name: TXN_WRITE_NOTIFICATION_LOG; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3869.dat

--
-- Data for Name: TYPES; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3824.dat

--
-- Data for Name: TYPE_FIELDS; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3825.dat

--
-- Data for Name: VERSION; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3835.dat

--
-- Data for Name: WM_MAPPING; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3847.dat

--
-- Data for Name: WM_POOL; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3844.dat

--
-- Data for Name: WM_POOL_TO_TRIGGER; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3846.dat

--
-- Data for Name: WM_RESOURCEPLAN; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3843.dat

--
-- Data for Name: WM_TRIGGER; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3845.dat

--
-- Data for Name: WRITE_SET; Type: TABLE DATA; Schema: public; Owner: admin
--

\i $$PATH$$/3860.dat

--
-- Name: MASTER_KEYS_KEY_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."MASTER_KEYS_KEY_ID_seq"', 1, false);


--
-- Name: TXNS_TXN_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public."TXNS_TXN_ID_seq"', 1, false);


--
-- Name: AUX_TABLE AUX_TABLE_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."AUX_TABLE"
    ADD CONSTRAINT "AUX_TABLE_pkey" PRIMARY KEY ("MT_KEY1", "MT_KEY2");


--
-- Name: BUCKETING_COLS BUCKETING_COLS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."BUCKETING_COLS"
    ADD CONSTRAINT "BUCKETING_COLS_pkey" PRIMARY KEY ("SD_ID", "INTEGER_IDX");


--
-- Name: CDS CDS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."CDS"
    ADD CONSTRAINT "CDS_pkey" PRIMARY KEY ("CD_ID");


--
-- Name: COLUMNS_V2 COLUMNS_V2_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."COLUMNS_V2"
    ADD CONSTRAINT "COLUMNS_V2_pkey" PRIMARY KEY ("CD_ID", "COLUMN_NAME");


--
-- Name: COMPACTION_QUEUE COMPACTION_QUEUE_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."COMPACTION_QUEUE"
    ADD CONSTRAINT "COMPACTION_QUEUE_pkey" PRIMARY KEY ("CQ_ID");


--
-- Name: COMPLETED_COMPACTIONS COMPLETED_COMPACTIONS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."COMPLETED_COMPACTIONS"
    ADD CONSTRAINT "COMPLETED_COMPACTIONS_pkey" PRIMARY KEY ("CC_ID");


--
-- Name: CTLGS CTLGS_NAME_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."CTLGS"
    ADD CONSTRAINT "CTLGS_NAME_key" UNIQUE ("NAME");


--
-- Name: CTLGS CTLGS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."CTLGS"
    ADD CONSTRAINT "CTLGS_pkey" PRIMARY KEY ("CTLG_ID");


--
-- Name: DATABASE_PARAMS DATABASE_PARAMS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."DATABASE_PARAMS"
    ADD CONSTRAINT "DATABASE_PARAMS_pkey" PRIMARY KEY ("DB_ID", "PARAM_KEY");


--
-- Name: DATACONNECTORS DATACONNECTORS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."DATACONNECTORS"
    ADD CONSTRAINT "DATACONNECTORS_pkey" PRIMARY KEY ("NAME");


--
-- Name: DATACONNECTOR_PARAMS DATACONNECTOR_PARAMS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."DATACONNECTOR_PARAMS"
    ADD CONSTRAINT "DATACONNECTOR_PARAMS_pkey" PRIMARY KEY ("NAME", "PARAM_KEY");


--
-- Name: DB_PRIVS DBPRIVILEGEINDEX; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."DB_PRIVS"
    ADD CONSTRAINT "DBPRIVILEGEINDEX" UNIQUE ("AUTHORIZER", "DB_ID", "PRINCIPAL_NAME", "PRINCIPAL_TYPE", "DB_PRIV", "GRANTOR", "GRANTOR_TYPE");


--
-- Name: DBS DBS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."DBS"
    ADD CONSTRAINT "DBS_pkey" PRIMARY KEY ("DB_ID");


--
-- Name: DB_PRIVS DB_PRIVS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."DB_PRIVS"
    ADD CONSTRAINT "DB_PRIVS_pkey" PRIMARY KEY ("DB_GRANT_ID");


--
-- Name: DC_PRIVS DCPRIVILEGEINDEX; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."DC_PRIVS"
    ADD CONSTRAINT "DCPRIVILEGEINDEX" UNIQUE ("AUTHORIZER", "NAME", "PRINCIPAL_NAME", "PRINCIPAL_TYPE", "DC_PRIV", "GRANTOR", "GRANTOR_TYPE");


--
-- Name: DC_PRIVS DC_PRIVS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."DC_PRIVS"
    ADD CONSTRAINT "DC_PRIVS_pkey" PRIMARY KEY ("DC_GRANT_ID");


--
-- Name: DELEGATION_TOKENS DELEGATION_TOKENS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."DELEGATION_TOKENS"
    ADD CONSTRAINT "DELEGATION_TOKENS_pkey" PRIMARY KEY ("TOKEN_IDENT");


--
-- Name: FUNCS FUNCS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."FUNCS"
    ADD CONSTRAINT "FUNCS_pkey" PRIMARY KEY ("FUNC_ID");


--
-- Name: FUNC_RU FUNC_RU_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."FUNC_RU"
    ADD CONSTRAINT "FUNC_RU_pkey" PRIMARY KEY ("FUNC_ID", "INTEGER_IDX");


--
-- Name: GLOBAL_PRIVS GLOBALPRIVILEGEINDEX; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."GLOBAL_PRIVS"
    ADD CONSTRAINT "GLOBALPRIVILEGEINDEX" UNIQUE ("AUTHORIZER", "PRINCIPAL_NAME", "PRINCIPAL_TYPE", "USER_PRIV", "GRANTOR", "GRANTOR_TYPE");


--
-- Name: GLOBAL_PRIVS GLOBAL_PRIVS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."GLOBAL_PRIVS"
    ADD CONSTRAINT "GLOBAL_PRIVS_pkey" PRIMARY KEY ("USER_GRANT_ID");


--
-- Name: HIVE_LOCKS HIVE_LOCKS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."HIVE_LOCKS"
    ADD CONSTRAINT "HIVE_LOCKS_pkey" PRIMARY KEY ("HL_LOCK_EXT_ID", "HL_LOCK_INT_ID");


--
-- Name: IDXS IDXS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."IDXS"
    ADD CONSTRAINT "IDXS_pkey" PRIMARY KEY ("INDEX_ID");


--
-- Name: INDEX_PARAMS INDEX_PARAMS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."INDEX_PARAMS"
    ADD CONSTRAINT "INDEX_PARAMS_pkey" PRIMARY KEY ("INDEX_ID", "PARAM_KEY");


--
-- Name: I_SCHEMA I_SCHEMA_NAME_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."I_SCHEMA"
    ADD CONSTRAINT "I_SCHEMA_NAME_key" UNIQUE ("NAME");


--
-- Name: I_SCHEMA I_SCHEMA_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."I_SCHEMA"
    ADD CONSTRAINT "I_SCHEMA_pkey" PRIMARY KEY ("SCHEMA_ID");


--
-- Name: MASTER_KEYS MASTER_KEYS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."MASTER_KEYS"
    ADD CONSTRAINT "MASTER_KEYS_pkey" PRIMARY KEY ("KEY_ID");


--
-- Name: MATERIALIZATION_REBUILD_LOCKS MATERIALIZATION_REBUILD_LOCKS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."MATERIALIZATION_REBUILD_LOCKS"
    ADD CONSTRAINT "MATERIALIZATION_REBUILD_LOCKS_pkey" PRIMARY KEY ("MRL_TXN_ID");


--
-- Name: MIN_HISTORY_LEVEL MIN_HISTORY_LEVEL_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."MIN_HISTORY_LEVEL"
    ADD CONSTRAINT "MIN_HISTORY_LEVEL_pkey" PRIMARY KEY ("MHL_TXNID");


--
-- Name: MV_CREATION_METADATA MV_CREATION_METADATA_PK; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."MV_CREATION_METADATA"
    ADD CONSTRAINT "MV_CREATION_METADATA_PK" PRIMARY KEY ("MV_CREATION_METADATA_ID");


--
-- Name: MV_TABLES_USED MV_TABLES_USED_PK; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."MV_TABLES_USED"
    ADD CONSTRAINT "MV_TABLES_USED_PK" PRIMARY KEY ("TBL_ID", "MV_CREATION_METADATA_ID");


--
-- Name: NOTIFICATION_LOG NOTIFICATION_LOG_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."NOTIFICATION_LOG"
    ADD CONSTRAINT "NOTIFICATION_LOG_pkey" PRIMARY KEY ("NL_ID");


--
-- Name: NOTIFICATION_SEQUENCE NOTIFICATION_SEQUENCE_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."NOTIFICATION_SEQUENCE"
    ADD CONSTRAINT "NOTIFICATION_SEQUENCE_pkey" PRIMARY KEY ("NNI_ID");


--
-- Name: NUCLEUS_TABLES NUCLEUS_TABLES_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."NUCLEUS_TABLES"
    ADD CONSTRAINT "NUCLEUS_TABLES_pkey" PRIMARY KEY ("CLASS_NAME");


--
-- Name: PACKAGES PACKAGES_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PACKAGES"
    ADD CONSTRAINT "PACKAGES_pkey" PRIMARY KEY ("PKG_ID");


--
-- Name: PARTITIONS PARTITIONS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PARTITIONS"
    ADD CONSTRAINT "PARTITIONS_pkey" PRIMARY KEY ("PART_ID");


--
-- Name: PARTITION_EVENTS PARTITION_EVENTS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PARTITION_EVENTS"
    ADD CONSTRAINT "PARTITION_EVENTS_pkey" PRIMARY KEY ("PART_NAME_ID");


--
-- Name: PARTITION_KEYS PARTITION_KEYS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PARTITION_KEYS"
    ADD CONSTRAINT "PARTITION_KEYS_pkey" PRIMARY KEY ("TBL_ID", "PKEY_NAME");


--
-- Name: PARTITION_KEY_VALS PARTITION_KEY_VALS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PARTITION_KEY_VALS"
    ADD CONSTRAINT "PARTITION_KEY_VALS_pkey" PRIMARY KEY ("PART_ID", "INTEGER_IDX");


--
-- Name: PARTITION_PARAMS PARTITION_PARAMS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PARTITION_PARAMS"
    ADD CONSTRAINT "PARTITION_PARAMS_pkey" PRIMARY KEY ("PART_ID", "PARAM_KEY");


--
-- Name: PART_COL_PRIVS PART_COL_PRIVS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PART_COL_PRIVS"
    ADD CONSTRAINT "PART_COL_PRIVS_pkey" PRIMARY KEY ("PART_COLUMN_GRANT_ID");


--
-- Name: PART_COL_STATS PART_COL_STATS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PART_COL_STATS"
    ADD CONSTRAINT "PART_COL_STATS_pkey" PRIMARY KEY ("CS_ID");


--
-- Name: PART_PRIVS PART_PRIVS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PART_PRIVS"
    ADD CONSTRAINT "PART_PRIVS_pkey" PRIMARY KEY ("PART_GRANT_ID");


--
-- Name: METASTORE_DB_PROPERTIES PROPERTY_KEY_PK; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."METASTORE_DB_PROPERTIES"
    ADD CONSTRAINT "PROPERTY_KEY_PK" PRIMARY KEY ("PROPERTY_KEY");


--
-- Name: REPLICATION_METRICS REPLICATION_METRICS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."REPLICATION_METRICS"
    ADD CONSTRAINT "REPLICATION_METRICS_pkey" PRIMARY KEY ("RM_SCHEDULED_EXECUTION_ID");


--
-- Name: REPL_TXN_MAP REPL_TXN_MAP_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."REPL_TXN_MAP"
    ADD CONSTRAINT "REPL_TXN_MAP_pkey" PRIMARY KEY ("RTM_REPL_POLICY", "RTM_SRC_TXN_ID");


--
-- Name: ROLES ROLEENTITYINDEX; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ROLES"
    ADD CONSTRAINT "ROLEENTITYINDEX" UNIQUE ("ROLE_NAME");


--
-- Name: ROLES ROLES_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ROLES"
    ADD CONSTRAINT "ROLES_pkey" PRIMARY KEY ("ROLE_ID");


--
-- Name: ROLE_MAP ROLE_MAP_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ROLE_MAP"
    ADD CONSTRAINT "ROLE_MAP_pkey" PRIMARY KEY ("ROLE_GRANT_ID");


--
-- Name: RUNTIME_STATS RUNTIME_STATS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."RUNTIME_STATS"
    ADD CONSTRAINT "RUNTIME_STATS_pkey" PRIMARY KEY ("RS_ID");


--
-- Name: SCHEDULED_EXECUTIONS SCHEDULED_EXECUTIONS_PK; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SCHEDULED_EXECUTIONS"
    ADD CONSTRAINT "SCHEDULED_EXECUTIONS_PK" PRIMARY KEY ("SCHEDULED_EXECUTION_ID");


--
-- Name: SCHEDULED_QUERIES SCHEDULED_QUERIES_PK; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SCHEDULED_QUERIES"
    ADD CONSTRAINT "SCHEDULED_QUERIES_PK" PRIMARY KEY ("SCHEDULED_QUERY_ID");


--
-- Name: SCHEMA_VERSION SCHEMA_VERSION_SCHEMA_ID_VERSION_key; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SCHEMA_VERSION"
    ADD CONSTRAINT "SCHEMA_VERSION_SCHEMA_ID_VERSION_key" UNIQUE ("SCHEMA_ID", "VERSION");


--
-- Name: SCHEMA_VERSION SCHEMA_VERSION_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SCHEMA_VERSION"
    ADD CONSTRAINT "SCHEMA_VERSION_pkey" PRIMARY KEY ("SCHEMA_VERSION_ID");


--
-- Name: SDS SDS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SDS"
    ADD CONSTRAINT "SDS_pkey" PRIMARY KEY ("SD_ID");


--
-- Name: SD_PARAMS SD_PARAMS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SD_PARAMS"
    ADD CONSTRAINT "SD_PARAMS_pkey" PRIMARY KEY ("SD_ID", "PARAM_KEY");


--
-- Name: SEQUENCE_TABLE SEQUENCE_TABLE_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SEQUENCE_TABLE"
    ADD CONSTRAINT "SEQUENCE_TABLE_pkey" PRIMARY KEY ("SEQUENCE_NAME");


--
-- Name: SERDES SERDES_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SERDES"
    ADD CONSTRAINT "SERDES_pkey" PRIMARY KEY ("SERDE_ID");


--
-- Name: SERDE_PARAMS SERDE_PARAMS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SERDE_PARAMS"
    ADD CONSTRAINT "SERDE_PARAMS_pkey" PRIMARY KEY ("SERDE_ID", "PARAM_KEY");


--
-- Name: SKEWED_COL_NAMES SKEWED_COL_NAMES_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SKEWED_COL_NAMES"
    ADD CONSTRAINT "SKEWED_COL_NAMES_pkey" PRIMARY KEY ("SD_ID", "INTEGER_IDX");


--
-- Name: SKEWED_COL_VALUE_LOC_MAP SKEWED_COL_VALUE_LOC_MAP_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SKEWED_COL_VALUE_LOC_MAP"
    ADD CONSTRAINT "SKEWED_COL_VALUE_LOC_MAP_pkey" PRIMARY KEY ("SD_ID", "STRING_LIST_ID_KID");


--
-- Name: SKEWED_STRING_LIST_VALUES SKEWED_STRING_LIST_VALUES_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SKEWED_STRING_LIST_VALUES"
    ADD CONSTRAINT "SKEWED_STRING_LIST_VALUES_pkey" PRIMARY KEY ("STRING_LIST_ID", "INTEGER_IDX");


--
-- Name: SKEWED_STRING_LIST SKEWED_STRING_LIST_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SKEWED_STRING_LIST"
    ADD CONSTRAINT "SKEWED_STRING_LIST_pkey" PRIMARY KEY ("STRING_LIST_ID");


--
-- Name: SKEWED_VALUES SKEWED_VALUES_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SKEWED_VALUES"
    ADD CONSTRAINT "SKEWED_VALUES_pkey" PRIMARY KEY ("SD_ID_OID", "INTEGER_IDX");


--
-- Name: SORT_COLS SORT_COLS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SORT_COLS"
    ADD CONSTRAINT "SORT_COLS_pkey" PRIMARY KEY ("SD_ID", "INTEGER_IDX");


--
-- Name: STORED_PROCS STORED_PROCS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."STORED_PROCS"
    ADD CONSTRAINT "STORED_PROCS_pkey" PRIMARY KEY ("SP_ID");


--
-- Name: TABLE_PARAMS TABLE_PARAMS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TABLE_PARAMS"
    ADD CONSTRAINT "TABLE_PARAMS_pkey" PRIMARY KEY ("TBL_ID", "PARAM_KEY");


--
-- Name: TAB_COL_STATS TAB_COL_STATS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TAB_COL_STATS"
    ADD CONSTRAINT "TAB_COL_STATS_pkey" PRIMARY KEY ("CS_ID");


--
-- Name: TBLS TBLS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TBLS"
    ADD CONSTRAINT "TBLS_pkey" PRIMARY KEY ("TBL_ID");


--
-- Name: TBL_COL_PRIVS TBL_COL_PRIVS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TBL_COL_PRIVS"
    ADD CONSTRAINT "TBL_COL_PRIVS_pkey" PRIMARY KEY ("TBL_COLUMN_GRANT_ID");


--
-- Name: TBL_PRIVS TBL_PRIVS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TBL_PRIVS"
    ADD CONSTRAINT "TBL_PRIVS_pkey" PRIMARY KEY ("TBL_GRANT_ID");


--
-- Name: TXNS TXNS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TXNS"
    ADD CONSTRAINT "TXNS_pkey" PRIMARY KEY ("TXN_ID");


--
-- Name: TXN_WRITE_NOTIFICATION_LOG TXN_WRITE_NOTIFICATION_LOG_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TXN_WRITE_NOTIFICATION_LOG"
    ADD CONSTRAINT "TXN_WRITE_NOTIFICATION_LOG_pkey" PRIMARY KEY ("WNL_TXNID", "WNL_DATABASE", "WNL_TABLE", "WNL_PARTITION");


--
-- Name: TYPES TYPES_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TYPES"
    ADD CONSTRAINT "TYPES_pkey" PRIMARY KEY ("TYPES_ID");


--
-- Name: TYPE_FIELDS TYPE_FIELDS_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TYPE_FIELDS"
    ADD CONSTRAINT "TYPE_FIELDS_pkey" PRIMARY KEY ("TYPE_NAME", "FIELD_NAME");


--
-- Name: IDXS UNIQUEINDEX; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."IDXS"
    ADD CONSTRAINT "UNIQUEINDEX" UNIQUE ("INDEX_NAME", "ORIG_TBL_ID");


--
-- Name: PARTITIONS UNIQUEPARTITION; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PARTITIONS"
    ADD CONSTRAINT "UNIQUEPARTITION" UNIQUE ("PART_NAME", "TBL_ID");


--
-- Name: TBLS UNIQUETABLE; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TBLS"
    ADD CONSTRAINT "UNIQUETABLE" UNIQUE ("TBL_NAME", "DB_ID");


--
-- Name: DBS UNIQUE_DATABASE; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."DBS"
    ADD CONSTRAINT "UNIQUE_DATABASE" UNIQUE ("NAME", "CTLG_NAME");


--
-- Name: TYPES UNIQUE_TYPE; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TYPES"
    ADD CONSTRAINT "UNIQUE_TYPE" UNIQUE ("TYPE_NAME");


--
-- Name: WM_MAPPING UNIQUE_WM_MAPPING; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."WM_MAPPING"
    ADD CONSTRAINT "UNIQUE_WM_MAPPING" UNIQUE ("RP_ID", "ENTITY_TYPE", "ENTITY_NAME");


--
-- Name: WM_POOL UNIQUE_WM_POOL; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."WM_POOL"
    ADD CONSTRAINT "UNIQUE_WM_POOL" UNIQUE ("RP_ID", "PATH");


--
-- Name: WM_RESOURCEPLAN UNIQUE_WM_RESOURCEPLAN; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."WM_RESOURCEPLAN"
    ADD CONSTRAINT "UNIQUE_WM_RESOURCEPLAN" UNIQUE ("NS", "NAME");


--
-- Name: WM_TRIGGER UNIQUE_WM_TRIGGER; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."WM_TRIGGER"
    ADD CONSTRAINT "UNIQUE_WM_TRIGGER" UNIQUE ("RP_ID", "NAME");


--
-- Name: ROLE_MAP USERROLEMAPINDEX; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ROLE_MAP"
    ADD CONSTRAINT "USERROLEMAPINDEX" UNIQUE ("PRINCIPAL_NAME", "ROLE_ID", "GRANTOR", "GRANTOR_TYPE");


--
-- Name: VERSION VERSION_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."VERSION"
    ADD CONSTRAINT "VERSION_pkey" PRIMARY KEY ("VER_ID");


--
-- Name: WM_MAPPING WM_MAPPING_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."WM_MAPPING"
    ADD CONSTRAINT "WM_MAPPING_pkey" PRIMARY KEY ("MAPPING_ID");


--
-- Name: WM_POOL_TO_TRIGGER WM_POOL_TO_TRIGGER_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."WM_POOL_TO_TRIGGER"
    ADD CONSTRAINT "WM_POOL_TO_TRIGGER_pkey" PRIMARY KEY ("POOL_ID", "TRIGGER_ID");


--
-- Name: WM_POOL WM_POOL_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."WM_POOL"
    ADD CONSTRAINT "WM_POOL_pkey" PRIMARY KEY ("POOL_ID");


--
-- Name: WM_RESOURCEPLAN WM_RESOURCEPLAN_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."WM_RESOURCEPLAN"
    ADD CONSTRAINT "WM_RESOURCEPLAN_pkey" PRIMARY KEY ("RP_ID");


--
-- Name: WM_TRIGGER WM_TRIGGER_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."WM_TRIGGER"
    ADD CONSTRAINT "WM_TRIGGER_pkey" PRIMARY KEY ("TRIGGER_ID");


--
-- Name: KEY_CONSTRAINTS constraints_pk; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."KEY_CONSTRAINTS"
    ADD CONSTRAINT constraints_pk PRIMARY KEY ("PARENT_TBL_ID", "CONSTRAINT_NAME", "POSITION");


--
-- Name: BUCKETING_COLS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "BUCKETING_COLS_N49" ON public."BUCKETING_COLS" USING btree ("SD_ID");


--
-- Name: COMPLETED_COMPACTIONS_RES; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "COMPLETED_COMPACTIONS_RES" ON public."COMPLETED_COMPACTIONS" USING btree ("CC_DATABASE", "CC_TABLE", "CC_PARTITION");


--
-- Name: CONSTRAINTS_CONSTRAINT_TYPE_INDEX; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "CONSTRAINTS_CONSTRAINT_TYPE_INDEX" ON public."KEY_CONSTRAINTS" USING btree ("CONSTRAINT_TYPE");


--
-- Name: CONSTRAINTS_PARENT_TBLID_INDEX; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "CONSTRAINTS_PARENT_TBLID_INDEX" ON public."KEY_CONSTRAINTS" USING btree ("PARENT_TBL_ID");


--
-- Name: DATABASE_PARAMS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "DATABASE_PARAMS_N49" ON public."DATABASE_PARAMS" USING btree ("DB_ID");


--
-- Name: DB_PRIVS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "DB_PRIVS_N49" ON public."DB_PRIVS" USING btree ("DB_ID");


--
-- Name: DC_PRIVS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "DC_PRIVS_N49" ON public."DC_PRIVS" USING btree ("NAME");


--
-- Name: DUMP_IDX; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "DUMP_IDX" ON public."REPLICATION_METRICS" USING btree ("RM_DUMP_EXECUTION_ID");


--
-- Name: FUNCS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "FUNCS_N49" ON public."FUNCS" USING btree ("DB_ID");


--
-- Name: FUNC_RU_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "FUNC_RU_N49" ON public."FUNC_RU" USING btree ("FUNC_ID");


--
-- Name: IDXS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "IDXS_N49" ON public."IDXS" USING btree ("ORIG_TBL_ID");


--
-- Name: IDXS_N50; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "IDXS_N50" ON public."IDXS" USING btree ("INDEX_TBL_ID");


--
-- Name: IDXS_N51; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "IDXS_N51" ON public."IDXS" USING btree ("SD_ID");


--
-- Name: IDX_RUNTIME_STATS_CREATE_TIME; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "IDX_RUNTIME_STATS_CREATE_TIME" ON public."RUNTIME_STATS" USING btree ("CREATE_TIME");


--
-- Name: INDEX_PARAMS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "INDEX_PARAMS_N49" ON public."INDEX_PARAMS" USING btree ("INDEX_ID");


--
-- Name: MIN_HISTORY_LEVEL_IDX; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "MIN_HISTORY_LEVEL_IDX" ON public."MIN_HISTORY_LEVEL" USING btree ("MHL_MIN_OPEN_TXNID");


--
-- Name: MV_UNIQUE_TABLE; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "MV_UNIQUE_TABLE" ON public."MV_CREATION_METADATA" USING btree ("TBL_NAME", "DB_NAME");


--
-- Name: NEXT_WRITE_ID_IDX; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "NEXT_WRITE_ID_IDX" ON public."NEXT_WRITE_ID" USING btree ("NWI_DATABASE", "NWI_TABLE");


--
-- Name: NOTIFICATION_LOG_EVENT_ID; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "NOTIFICATION_LOG_EVENT_ID" ON public."NOTIFICATION_LOG" USING btree ("EVENT_ID");


--
-- Name: PARTITIONCOLUMNPRIVILEGEINDEX; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "PARTITIONCOLUMNPRIVILEGEINDEX" ON public."PART_COL_PRIVS" USING btree ("AUTHORIZER", "PART_ID", "COLUMN_NAME", "PRINCIPAL_NAME", "PRINCIPAL_TYPE", "PART_COL_PRIV", "GRANTOR", "GRANTOR_TYPE");


--
-- Name: PARTITIONEVENTINDEX; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "PARTITIONEVENTINDEX" ON public."PARTITION_EVENTS" USING btree ("PARTITION_NAME");


--
-- Name: PARTITIONS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "PARTITIONS_N49" ON public."PARTITIONS" USING btree ("TBL_ID");


--
-- Name: PARTITIONS_N50; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "PARTITIONS_N50" ON public."PARTITIONS" USING btree ("SD_ID");


--
-- Name: PARTITION_KEYS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "PARTITION_KEYS_N49" ON public."PARTITION_KEYS" USING btree ("TBL_ID");


--
-- Name: PARTITION_KEY_VALS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "PARTITION_KEY_VALS_N49" ON public."PARTITION_KEY_VALS" USING btree ("PART_ID");


--
-- Name: PARTITION_PARAMS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "PARTITION_PARAMS_N49" ON public."PARTITION_PARAMS" USING btree ("PART_ID");


--
-- Name: PARTPRIVILEGEINDEX; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "PARTPRIVILEGEINDEX" ON public."PART_PRIVS" USING btree ("AUTHORIZER", "PART_ID", "PRINCIPAL_NAME", "PRINCIPAL_TYPE", "PART_PRIV", "GRANTOR", "GRANTOR_TYPE");


--
-- Name: PART_COL_PRIVS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "PART_COL_PRIVS_N49" ON public."PART_COL_PRIVS" USING btree ("PART_ID");


--
-- Name: PART_COL_STATS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "PART_COL_STATS_N49" ON public."PART_COL_STATS" USING btree ("PART_ID");


--
-- Name: PART_PRIVS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "PART_PRIVS_N49" ON public."PART_PRIVS" USING btree ("PART_ID");


--
-- Name: PCS_STATS_IDX; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "PCS_STATS_IDX" ON public."PART_COL_STATS" USING btree ("CAT_NAME", "DB_NAME", "TABLE_NAME", "COLUMN_NAME", "PARTITION_NAME");


--
-- Name: POLICY_IDX; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "POLICY_IDX" ON public."REPLICATION_METRICS" USING btree ("RM_POLICY");


--
-- Name: ROLE_MAP_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "ROLE_MAP_N49" ON public."ROLE_MAP" USING btree ("ROLE_ID");


--
-- Name: SDS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "SDS_N49" ON public."SDS" USING btree ("SERDE_ID");


--
-- Name: SDS_N50; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "SDS_N50" ON public."SDS" USING btree ("CD_ID");


--
-- Name: SD_PARAMS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "SD_PARAMS_N49" ON public."SD_PARAMS" USING btree ("SD_ID");


--
-- Name: SERDE_PARAMS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "SERDE_PARAMS_N49" ON public."SERDE_PARAMS" USING btree ("SERDE_ID");


--
-- Name: SORT_COLS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "SORT_COLS_N49" ON public."SORT_COLS" USING btree ("SD_ID");


--
-- Name: TABLECOLUMNPRIVILEGEINDEX; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "TABLECOLUMNPRIVILEGEINDEX" ON public."TBL_COL_PRIVS" USING btree ("AUTHORIZER", "TBL_ID", "COLUMN_NAME", "PRINCIPAL_NAME", "PRINCIPAL_TYPE", "TBL_COL_PRIV", "GRANTOR", "GRANTOR_TYPE");


--
-- Name: TABLEPRIVILEGEINDEX; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "TABLEPRIVILEGEINDEX" ON public."TBL_PRIVS" USING btree ("AUTHORIZER", "TBL_ID", "PRINCIPAL_NAME", "PRINCIPAL_TYPE", "TBL_PRIV", "GRANTOR", "GRANTOR_TYPE");


--
-- Name: TABLE_PARAMS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "TABLE_PARAMS_N49" ON public."TABLE_PARAMS" USING btree ("TBL_ID");


--
-- Name: TAB_COL_STATS_IDX; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "TAB_COL_STATS_IDX" ON public."TAB_COL_STATS" USING btree ("CAT_NAME", "DB_NAME", "TABLE_NAME", "COLUMN_NAME");


--
-- Name: TAB_COL_STATS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "TAB_COL_STATS_N49" ON public."TAB_COL_STATS" USING btree ("TBL_ID");


--
-- Name: TBLS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "TBLS_N49" ON public."TBLS" USING btree ("DB_ID");


--
-- Name: TBLS_N50; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "TBLS_N50" ON public."TBLS" USING btree ("SD_ID");


--
-- Name: TBL_COL_PRIVS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "TBL_COL_PRIVS_N49" ON public."TBL_COL_PRIVS" USING btree ("TBL_ID");


--
-- Name: TBL_PRIVS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "TBL_PRIVS_N49" ON public."TBL_PRIVS" USING btree ("TBL_ID");


--
-- Name: TBL_TO_TXN_ID_IDX; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "TBL_TO_TXN_ID_IDX" ON public."TXN_TO_WRITE_ID" USING btree ("T2W_DATABASE", "T2W_TABLE", "T2W_TXNID");


--
-- Name: TBL_TO_WRITE_ID_IDX; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "TBL_TO_WRITE_ID_IDX" ON public."TXN_TO_WRITE_ID" USING btree ("T2W_DATABASE", "T2W_TABLE", "T2W_WRITEID");


--
-- Name: TYPE_FIELDS_N49; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX "TYPE_FIELDS_N49" ON public."TYPE_FIELDS" USING btree ("TYPE_NAME");


--
-- Name: UNIQUEFUNCTION; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "UNIQUEFUNCTION" ON public."FUNCS" USING btree ("FUNC_NAME", "DB_ID");


--
-- Name: UNIQUEPKG; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "UNIQUEPKG" ON public."PACKAGES" USING btree ("NAME", "DB_ID");


--
-- Name: UNIQUESTOREDPROC; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX "UNIQUESTOREDPROC" ON public."STORED_PROCS" USING btree ("NAME", "DB_ID");


--
-- Name: completed_txn_components_index; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX completed_txn_components_index ON public."COMPLETED_TXN_COMPONENTS" USING btree ("CTC_DATABASE", "CTC_TABLE", "CTC_PARTITION");


--
-- Name: hl_txnid_index; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX hl_txnid_index ON public."HIVE_LOCKS" USING hash ("HL_TXNID");


--
-- Name: idx_scheduled_executions_last_update_time; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_scheduled_executions_last_update_time ON public."SCHEDULED_EXECUTIONS" USING btree ("LAST_UPDATE_TIME");


--
-- Name: idx_scheduled_executions_scheduled_query_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX idx_scheduled_executions_scheduled_query_id ON public."SCHEDULED_EXECUTIONS" USING btree ("SCHEDULED_QUERY_ID");


--
-- Name: tc_txnid_index; Type: INDEX; Schema: public; Owner: admin
--

CREATE INDEX tc_txnid_index ON public."TXN_COMPONENTS" USING hash ("TC_TXNID");


--
-- Name: unique_scheduled_executions_id; Type: INDEX; Schema: public; Owner: admin
--

CREATE UNIQUE INDEX unique_scheduled_executions_id ON public."SCHEDULED_EXECUTIONS" USING btree ("SCHEDULED_EXECUTION_ID");


--
-- Name: BUCKETING_COLS BUCKETING_COLS_SD_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."BUCKETING_COLS"
    ADD CONSTRAINT "BUCKETING_COLS_SD_ID_fkey" FOREIGN KEY ("SD_ID") REFERENCES public."SDS"("SD_ID") DEFERRABLE;


--
-- Name: COLUMNS_V2 COLUMNS_V2_CD_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."COLUMNS_V2"
    ADD CONSTRAINT "COLUMNS_V2_CD_ID_fkey" FOREIGN KEY ("CD_ID") REFERENCES public."CDS"("CD_ID") DEFERRABLE;


--
-- Name: DATABASE_PARAMS DATABASE_PARAMS_DB_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."DATABASE_PARAMS"
    ADD CONSTRAINT "DATABASE_PARAMS_DB_ID_fkey" FOREIGN KEY ("DB_ID") REFERENCES public."DBS"("DB_ID") DEFERRABLE;


--
-- Name: DATACONNECTOR_PARAMS DATACONNECTOR_NAME_FK1; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."DATACONNECTOR_PARAMS"
    ADD CONSTRAINT "DATACONNECTOR_NAME_FK1" FOREIGN KEY ("NAME") REFERENCES public."DATACONNECTORS"("NAME") ON DELETE CASCADE;


--
-- Name: DBS DBS_FK1; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."DBS"
    ADD CONSTRAINT "DBS_FK1" FOREIGN KEY ("CTLG_NAME") REFERENCES public."CTLGS"("NAME");


--
-- Name: DB_PRIVS DB_PRIVS_DB_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."DB_PRIVS"
    ADD CONSTRAINT "DB_PRIVS_DB_ID_fkey" FOREIGN KEY ("DB_ID") REFERENCES public."DBS"("DB_ID") DEFERRABLE;


--
-- Name: DC_PRIVS DC_PRIVS_DC_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."DC_PRIVS"
    ADD CONSTRAINT "DC_PRIVS_DC_ID_fkey" FOREIGN KEY ("NAME") REFERENCES public."DATACONNECTORS"("NAME") DEFERRABLE;


--
-- Name: FUNCS FUNCS_FK1; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."FUNCS"
    ADD CONSTRAINT "FUNCS_FK1" FOREIGN KEY ("DB_ID") REFERENCES public."DBS"("DB_ID") DEFERRABLE;


--
-- Name: FUNC_RU FUNC_RU_FK1; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."FUNC_RU"
    ADD CONSTRAINT "FUNC_RU_FK1" FOREIGN KEY ("FUNC_ID") REFERENCES public."FUNCS"("FUNC_ID") DEFERRABLE;


--
-- Name: IDXS IDXS_INDEX_TBL_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."IDXS"
    ADD CONSTRAINT "IDXS_INDEX_TBL_ID_fkey" FOREIGN KEY ("INDEX_TBL_ID") REFERENCES public."TBLS"("TBL_ID") DEFERRABLE;


--
-- Name: IDXS IDXS_ORIG_TBL_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."IDXS"
    ADD CONSTRAINT "IDXS_ORIG_TBL_ID_fkey" FOREIGN KEY ("ORIG_TBL_ID") REFERENCES public."TBLS"("TBL_ID") DEFERRABLE;


--
-- Name: IDXS IDXS_SD_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."IDXS"
    ADD CONSTRAINT "IDXS_SD_ID_fkey" FOREIGN KEY ("SD_ID") REFERENCES public."SDS"("SD_ID") DEFERRABLE;


--
-- Name: INDEX_PARAMS INDEX_PARAMS_INDEX_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."INDEX_PARAMS"
    ADD CONSTRAINT "INDEX_PARAMS_INDEX_ID_fkey" FOREIGN KEY ("INDEX_ID") REFERENCES public."IDXS"("INDEX_ID") DEFERRABLE;


--
-- Name: I_SCHEMA I_SCHEMA_DB_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."I_SCHEMA"
    ADD CONSTRAINT "I_SCHEMA_DB_ID_fkey" FOREIGN KEY ("DB_ID") REFERENCES public."DBS"("DB_ID");


--
-- Name: MV_TABLES_USED MV_TABLES_USED_FK1; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."MV_TABLES_USED"
    ADD CONSTRAINT "MV_TABLES_USED_FK1" FOREIGN KEY ("MV_CREATION_METADATA_ID") REFERENCES public."MV_CREATION_METADATA"("MV_CREATION_METADATA_ID") DEFERRABLE;


--
-- Name: MV_TABLES_USED MV_TABLES_USED_FK2; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."MV_TABLES_USED"
    ADD CONSTRAINT "MV_TABLES_USED_FK2" FOREIGN KEY ("TBL_ID") REFERENCES public."TBLS"("TBL_ID") DEFERRABLE;


--
-- Name: PACKAGES PACKAGES_FK1; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PACKAGES"
    ADD CONSTRAINT "PACKAGES_FK1" FOREIGN KEY ("DB_ID") REFERENCES public."DBS"("DB_ID") DEFERRABLE;


--
-- Name: PARTITIONS PARTITIONS_SD_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PARTITIONS"
    ADD CONSTRAINT "PARTITIONS_SD_ID_fkey" FOREIGN KEY ("SD_ID") REFERENCES public."SDS"("SD_ID") DEFERRABLE;


--
-- Name: PARTITIONS PARTITIONS_TBL_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PARTITIONS"
    ADD CONSTRAINT "PARTITIONS_TBL_ID_fkey" FOREIGN KEY ("TBL_ID") REFERENCES public."TBLS"("TBL_ID") DEFERRABLE;


--
-- Name: PARTITION_KEYS PARTITION_KEYS_TBL_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PARTITION_KEYS"
    ADD CONSTRAINT "PARTITION_KEYS_TBL_ID_fkey" FOREIGN KEY ("TBL_ID") REFERENCES public."TBLS"("TBL_ID") DEFERRABLE;


--
-- Name: PARTITION_KEY_VALS PARTITION_KEY_VALS_PART_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PARTITION_KEY_VALS"
    ADD CONSTRAINT "PARTITION_KEY_VALS_PART_ID_fkey" FOREIGN KEY ("PART_ID") REFERENCES public."PARTITIONS"("PART_ID") DEFERRABLE;


--
-- Name: PARTITION_PARAMS PARTITION_PARAMS_PART_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PARTITION_PARAMS"
    ADD CONSTRAINT "PARTITION_PARAMS_PART_ID_fkey" FOREIGN KEY ("PART_ID") REFERENCES public."PARTITIONS"("PART_ID") DEFERRABLE;


--
-- Name: PART_COL_PRIVS PART_COL_PRIVS_PART_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PART_COL_PRIVS"
    ADD CONSTRAINT "PART_COL_PRIVS_PART_ID_fkey" FOREIGN KEY ("PART_ID") REFERENCES public."PARTITIONS"("PART_ID") DEFERRABLE;


--
-- Name: PART_COL_STATS PART_COL_STATS_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PART_COL_STATS"
    ADD CONSTRAINT "PART_COL_STATS_fkey" FOREIGN KEY ("PART_ID") REFERENCES public."PARTITIONS"("PART_ID") DEFERRABLE;


--
-- Name: PART_PRIVS PART_PRIVS_PART_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."PART_PRIVS"
    ADD CONSTRAINT "PART_PRIVS_PART_ID_fkey" FOREIGN KEY ("PART_ID") REFERENCES public."PARTITIONS"("PART_ID") DEFERRABLE;


--
-- Name: ROLE_MAP ROLE_MAP_ROLE_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."ROLE_MAP"
    ADD CONSTRAINT "ROLE_MAP_ROLE_ID_fkey" FOREIGN KEY ("ROLE_ID") REFERENCES public."ROLES"("ROLE_ID") DEFERRABLE;


--
-- Name: SCHEDULED_EXECUTIONS SCHEDULED_EXECUTIONS_SCHQ_FK; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SCHEDULED_EXECUTIONS"
    ADD CONSTRAINT "SCHEDULED_EXECUTIONS_SCHQ_FK" FOREIGN KEY ("SCHEDULED_QUERY_ID") REFERENCES public."SCHEDULED_QUERIES"("SCHEDULED_QUERY_ID") ON DELETE CASCADE;


--
-- Name: SCHEMA_VERSION SCHEMA_VERSION_CD_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SCHEMA_VERSION"
    ADD CONSTRAINT "SCHEMA_VERSION_CD_ID_fkey" FOREIGN KEY ("CD_ID") REFERENCES public."CDS"("CD_ID");


--
-- Name: SCHEMA_VERSION SCHEMA_VERSION_SCHEMA_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SCHEMA_VERSION"
    ADD CONSTRAINT "SCHEMA_VERSION_SCHEMA_ID_fkey" FOREIGN KEY ("SCHEMA_ID") REFERENCES public."I_SCHEMA"("SCHEMA_ID");


--
-- Name: SCHEMA_VERSION SCHEMA_VERSION_SERDE_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SCHEMA_VERSION"
    ADD CONSTRAINT "SCHEMA_VERSION_SERDE_ID_fkey" FOREIGN KEY ("SERDE_ID") REFERENCES public."SERDES"("SERDE_ID");


--
-- Name: SDS SDS_CD_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SDS"
    ADD CONSTRAINT "SDS_CD_ID_fkey" FOREIGN KEY ("CD_ID") REFERENCES public."CDS"("CD_ID") DEFERRABLE;


--
-- Name: SDS SDS_SERDE_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SDS"
    ADD CONSTRAINT "SDS_SERDE_ID_fkey" FOREIGN KEY ("SERDE_ID") REFERENCES public."SERDES"("SERDE_ID") DEFERRABLE;


--
-- Name: SD_PARAMS SD_PARAMS_SD_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SD_PARAMS"
    ADD CONSTRAINT "SD_PARAMS_SD_ID_fkey" FOREIGN KEY ("SD_ID") REFERENCES public."SDS"("SD_ID") DEFERRABLE;


--
-- Name: SERDE_PARAMS SERDE_PARAMS_SERDE_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SERDE_PARAMS"
    ADD CONSTRAINT "SERDE_PARAMS_SERDE_ID_fkey" FOREIGN KEY ("SERDE_ID") REFERENCES public."SERDES"("SERDE_ID") DEFERRABLE;


--
-- Name: SKEWED_COL_NAMES SKEWED_COL_NAMES_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SKEWED_COL_NAMES"
    ADD CONSTRAINT "SKEWED_COL_NAMES_fkey" FOREIGN KEY ("SD_ID") REFERENCES public."SDS"("SD_ID") DEFERRABLE;


--
-- Name: SKEWED_COL_VALUE_LOC_MAP SKEWED_COL_VALUE_LOC_MAP_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SKEWED_COL_VALUE_LOC_MAP"
    ADD CONSTRAINT "SKEWED_COL_VALUE_LOC_MAP_fkey1" FOREIGN KEY ("SD_ID") REFERENCES public."SDS"("SD_ID") DEFERRABLE;


--
-- Name: SKEWED_COL_VALUE_LOC_MAP SKEWED_COL_VALUE_LOC_MAP_fkey2; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SKEWED_COL_VALUE_LOC_MAP"
    ADD CONSTRAINT "SKEWED_COL_VALUE_LOC_MAP_fkey2" FOREIGN KEY ("STRING_LIST_ID_KID") REFERENCES public."SKEWED_STRING_LIST"("STRING_LIST_ID") DEFERRABLE;


--
-- Name: SKEWED_STRING_LIST_VALUES SKEWED_STRING_LIST_VALUES_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SKEWED_STRING_LIST_VALUES"
    ADD CONSTRAINT "SKEWED_STRING_LIST_VALUES_fkey" FOREIGN KEY ("STRING_LIST_ID") REFERENCES public."SKEWED_STRING_LIST"("STRING_LIST_ID") DEFERRABLE;


--
-- Name: SKEWED_VALUES SKEWED_VALUES_fkey1; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SKEWED_VALUES"
    ADD CONSTRAINT "SKEWED_VALUES_fkey1" FOREIGN KEY ("STRING_LIST_ID_EID") REFERENCES public."SKEWED_STRING_LIST"("STRING_LIST_ID") DEFERRABLE;


--
-- Name: SKEWED_VALUES SKEWED_VALUES_fkey2; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SKEWED_VALUES"
    ADD CONSTRAINT "SKEWED_VALUES_fkey2" FOREIGN KEY ("SD_ID_OID") REFERENCES public."SDS"("SD_ID") DEFERRABLE;


--
-- Name: SORT_COLS SORT_COLS_SD_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."SORT_COLS"
    ADD CONSTRAINT "SORT_COLS_SD_ID_fkey" FOREIGN KEY ("SD_ID") REFERENCES public."SDS"("SD_ID") DEFERRABLE;


--
-- Name: STORED_PROCS STOREDPROC_FK1; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."STORED_PROCS"
    ADD CONSTRAINT "STOREDPROC_FK1" FOREIGN KEY ("DB_ID") REFERENCES public."DBS"("DB_ID") DEFERRABLE;


--
-- Name: TABLE_PARAMS TABLE_PARAMS_TBL_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TABLE_PARAMS"
    ADD CONSTRAINT "TABLE_PARAMS_TBL_ID_fkey" FOREIGN KEY ("TBL_ID") REFERENCES public."TBLS"("TBL_ID") DEFERRABLE;


--
-- Name: TAB_COL_STATS TAB_COL_STATS_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TAB_COL_STATS"
    ADD CONSTRAINT "TAB_COL_STATS_fkey" FOREIGN KEY ("TBL_ID") REFERENCES public."TBLS"("TBL_ID") DEFERRABLE;


--
-- Name: TBLS TBLS_DB_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TBLS"
    ADD CONSTRAINT "TBLS_DB_ID_fkey" FOREIGN KEY ("DB_ID") REFERENCES public."DBS"("DB_ID") DEFERRABLE;


--
-- Name: TBLS TBLS_SD_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TBLS"
    ADD CONSTRAINT "TBLS_SD_ID_fkey" FOREIGN KEY ("SD_ID") REFERENCES public."SDS"("SD_ID") DEFERRABLE;


--
-- Name: TBL_COL_PRIVS TBL_COL_PRIVS_TBL_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TBL_COL_PRIVS"
    ADD CONSTRAINT "TBL_COL_PRIVS_TBL_ID_fkey" FOREIGN KEY ("TBL_ID") REFERENCES public."TBLS"("TBL_ID") DEFERRABLE;


--
-- Name: TBL_PRIVS TBL_PRIVS_TBL_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TBL_PRIVS"
    ADD CONSTRAINT "TBL_PRIVS_TBL_ID_fkey" FOREIGN KEY ("TBL_ID") REFERENCES public."TBLS"("TBL_ID") DEFERRABLE;


--
-- Name: TXN_COMPONENTS TXN_COMPONENTS_TC_TXNID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TXN_COMPONENTS"
    ADD CONSTRAINT "TXN_COMPONENTS_TC_TXNID_fkey" FOREIGN KEY ("TC_TXNID") REFERENCES public."TXNS"("TXN_ID");


--
-- Name: TYPE_FIELDS TYPE_FIELDS_TYPE_NAME_fkey; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."TYPE_FIELDS"
    ADD CONSTRAINT "TYPE_FIELDS_TYPE_NAME_fkey" FOREIGN KEY ("TYPE_NAME") REFERENCES public."TYPES"("TYPES_ID") DEFERRABLE;


--
-- Name: WM_MAPPING WM_MAPPING_FK1; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."WM_MAPPING"
    ADD CONSTRAINT "WM_MAPPING_FK1" FOREIGN KEY ("RP_ID") REFERENCES public."WM_RESOURCEPLAN"("RP_ID") DEFERRABLE;


--
-- Name: WM_MAPPING WM_MAPPING_FK2; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."WM_MAPPING"
    ADD CONSTRAINT "WM_MAPPING_FK2" FOREIGN KEY ("POOL_ID") REFERENCES public."WM_POOL"("POOL_ID") DEFERRABLE;


--
-- Name: WM_POOL WM_POOL_FK1; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."WM_POOL"
    ADD CONSTRAINT "WM_POOL_FK1" FOREIGN KEY ("RP_ID") REFERENCES public."WM_RESOURCEPLAN"("RP_ID") DEFERRABLE;


--
-- Name: WM_POOL_TO_TRIGGER WM_POOL_TO_TRIGGER_FK1; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."WM_POOL_TO_TRIGGER"
    ADD CONSTRAINT "WM_POOL_TO_TRIGGER_FK1" FOREIGN KEY ("POOL_ID") REFERENCES public."WM_POOL"("POOL_ID") DEFERRABLE;


--
-- Name: WM_POOL_TO_TRIGGER WM_POOL_TO_TRIGGER_FK2; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."WM_POOL_TO_TRIGGER"
    ADD CONSTRAINT "WM_POOL_TO_TRIGGER_FK2" FOREIGN KEY ("TRIGGER_ID") REFERENCES public."WM_TRIGGER"("TRIGGER_ID") DEFERRABLE;


--
-- Name: WM_RESOURCEPLAN WM_RESOURCEPLAN_FK1; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."WM_RESOURCEPLAN"
    ADD CONSTRAINT "WM_RESOURCEPLAN_FK1" FOREIGN KEY ("DEFAULT_POOL_ID") REFERENCES public."WM_POOL"("POOL_ID") DEFERRABLE;


--
-- Name: WM_TRIGGER WM_TRIGGER_FK1; Type: FK CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public."WM_TRIGGER"
    ADD CONSTRAINT "WM_TRIGGER_FK1" FOREIGN KEY ("RP_ID") REFERENCES public."WM_RESOURCEPLAN"("RP_ID") DEFERRABLE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: admin
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

